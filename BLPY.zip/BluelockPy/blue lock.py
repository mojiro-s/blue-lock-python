import tkinter as tk
import math
import time
import random

# --- ИНИЦИАЛИЗАЦИЯ ЗВУКА ---
try:
    import pygame

    pygame.mixer.init()
    SOUND_ENABLED = True
    print("Звуковая система инициализирована")
except:
    SOUND_ENABLED = False
    print("Звук недоступен, играем без звука")


# --- ЗАГРУЗКА ЗВУКОВ ---
def load_sounds():
    if not SOUND_ENABLED:
        return {}

    sounds = {}
    sound_files = {
        "kick": "sounds/kick.wav",
        "goal": "sounds/goal.wav",
        "goal_too": "sounds/goal_too.wav",
        "tackle": "sounds/tackle.wav",
        "time_stop": "sounds/time_stop.wav",
        "checkmate": "sounds/checkmate.wav",
        "hulk_transform": "sounds/hulk_transform.wav",
        "meta_vision": "sounds/meta_vision.wav",
        "puzzle": "sounds/puzzle.wav",
        "black_hole": "sounds/black_hole.wav",
        "revolver": "sounds/revolver.wav",
        "rot": "sounds/rot.wav",
        "hook": "sounds/hook.wav",
        "hook2": "sounds/hook2.wav",
        "snake": "sounds/snake.wav",
        "rin": "sounds/rin.wav",
        "kaiser_dribble": "sounds/kaiser_dribble.wav",
    }

    loaded = {}
    for name, filepath in sound_files.items():
        try:
            loaded[name] = pygame.mixer.Sound(filepath)
            print(f"Загружен звук: {name}")
        except:
            print(f"Не удалось загрузить: {filepath}")

    return loaded


SOUNDS = load_sounds()


def play_sound(name):
    """Глобальная функция воспроизведения звука"""
    if SOUND_ENABLED and name in SOUNDS:
        try:
            SOUNDS[name].play()
        except:
            pass


def stop_sound(name):
    """Глобальная функция остановки звука"""
    if SOUND_ENABLED and name in SOUNDS:
        try:
            SOUNDS[name].stop()
        except:
            pass


# --- КОНФИГУРАЦИЯ ПЕРСОНАЖЕЙ ---
CHARACTER_TYPES = {
    "Hulk": {"name": "ХАЛК", "base_radius": 45, "desc": "Огромный размер\n\nСпособность делает его гигантом на время",
             "cd": 8.0},
    "Isagi": {"name": "ИСАГИ", "base_radius": 35,
              "desc": "Мета-видение\n\nВидит траекторию мяча и ставит щит",
              "cd": 10.0},
    "Rin": {"name": "РИН", "base_radius": 35, "desc": "Кручёные удары\n\nУвеличивает вражеские ворота и станит врага",
            "cd": 8.0},
    "Pudge": {"name": "ПУДЖ", "base_radius": 40, "desc": "Мясник\n\nС мячом: ROT\nБез мяча: Meat Hook",
              "cd": 10.0},
    "Aiku": {"name": "АЙКУ", "base_radius": 38,
             "desc": "Расцветающий цветок\n\nТелепортируется к мячу в защите", "cd": 15.0},
    "Kaiser": {"name": "КАЙЗЕР", "base_radius": 36,
               "desc": "Импакт Кайзера\n\nУсиленные удары и быстрые рывки", "cd": 10.0},
    "Nagi": {"name": "НАГИ", "base_radius": 37,
             "desc": "Гений Ловушки\n\n50% шкалы: Black Hole Trap\n100% шкалы: 5-зарядный Револьвер",
             "cd": 10.0},
    "Dio": {"name": "ДИО", "base_radius": 38,
            "desc": "THE WORLD\n\nТайм-стоп или Checkmate.", "cd": 20.0},
    "Naruto": {"name": "НАРУТО", "base_radius": 37,
               "desc": "Каунтер\n\nАура с хвостами. При попытке отбора - отталкивание и бафф", "cd": 12.0},
}

NAGI_QUOTES = [
    "Скучно...", "Я не выбирал этот талант.", "Футбол — это просто.",
    "Я хочу домой...", "Эгоист? Возможно.", "Покажи мне что-то интересное.",
    "Я хочу победить.", "Приятно познакомится, я - Сейширо Наги."
]

DIO_QUOTES = [
    "WRYYYYYYYY!!!", "Это был я, Дио!", "   Я отвергаю свою\nчеловечность, ДжоДжо!", "Muda Muda Muda!",
    "О, ты бросаешь мне вызов? Вместо того,\nчтобы убегать, ты идёшь прямо ко мне?", "Шах и мат."
]

NARUTO_QUOTES = [
    "Даттебайо!", "Я не сдамся!", "Я стану Хокаге!",
    "Расенган!", "Режим Лиса!", "Тень тысячи клонов!"
]


# --- УТИЛИТЫ ---
def hex_to_rgb(hex_col):
    hex_col = hex_col.lstrip('#')
    return tuple(int(hex_col[i:i + 2], 16) for i in (0, 2, 4))


def rgb_to_hex(rgb):
    return '#%02x%02x%02x' % rgb


def interpolate_color(c1, c2, t):
    rgb1 = hex_to_rgb(c1)
    rgb2 = hex_to_rgb(c2)
    r = int(rgb1[0] + (rgb2[0] - rgb1[0]) * t)
    g = int(rgb1[1] + (rgb2[1] - rgb1[1]) * t)
    b = int(rgb1[2] + (rgb2[2] - rgb1[2]) * t)
    return rgb_to_hex((r, g, b))


def lighten_color(hex_color, factor=0.3):
    rgb = hex_to_rgb(hex_color)
    r = min(255, int(rgb[0] + (255 - rgb[0]) * factor))
    g = min(255, int(rgb[1] + (255 - rgb[1]) * factor))
    b = min(255, int(rgb[2] + (255 - rgb[2]) * factor))
    return rgb_to_hex((r, g, b))


# --- ОСНОВНОЙ КЛАСС ИГРЫ ---
class BlueLockPro2026:
    def __init__(self, char1, char2, ai_mode=False, switch_goals=0):
        self.root = tk.Tk()
        self.root.title("BlueLock Impact 2026")
        self.sw = self.root.winfo_screenwidth()
        self.sh = self.root.winfo_screenheight()
        self.root.geometry(f"{self.sw}x{self.sh}+0+0")
        self.root.overrideredirect(True)
        self.root.attributes("-topmost", True)

        self.ai_mode = ai_mode
        self.switch_goals = switch_goals
        self.running = True

        self.no_cooldown = False
        self.game_sound_enabled = True

        self.canvas = tk.Canvas(self.root, width=self.sw, height=self.sh, bg="#007539", highlightthickness=0)
        self.canvas.pack()

        self.create_exit_button()
        self.create_debug_button()

        self.score = [0, 0]
        self.freeze_until = 0

        self.time_stop_until = 0
        self.ts_owner = None
        self.ts_factor = 0.0
        self.knives = []
        self.impact_effect = None
        self.puzzle_pieces = []
        self.naruto_particles = []
        self.nagi_particles = []
        self.nagi_void_aura = []
        self.skull_auras = []
        self.hulk_cracks = []
        self.hulk_transform_effects = []
        self.kaiser_petals = []

        self.goal_text_id = None
        self.active_warning = None
        self.last_scorer = None

        self.p1 = self.create_player(300, self.sh // 2, "#0d47a1", char1, "Blue")
        self.p2 = self.create_player(self.sw - 300, self.sh // 2, "#b71c1c", char2, "Red")

        self.ball = {"x": self.sw // 2, "y": self.sh // 2, "dx": 0, "dy": 0, "radius": 24,
                     "kick_t": 0, "steal_t": 0, "dribbler": None, "curve": 0, "rotation": 0}

        self.hook = {"active": False, "x": 0, "y": 0, "dx": 0, "dy": 0, "owner": None, "target": None, "dist": 0}

        self.gw, self.gh_base = 25, 450
        self.gy1_blue, self.gy2_blue = self.sh // 2 - self.gh_base // 2, self.sh // 2 + self.gh_base // 2
        self.gy1_red, self.gy2_red = self.sh // 2 - self.gh_base // 2, self.sh // 2 + self.gh_base // 2

        self.gk_blue = {"x": 35, "y": self.sh // 2, "radius": 20, "side": "Blue"}
        self.gk_red = {"x": self.sw - 35, "y": self.sh // 2, "radius": 20, "side": "Red"}

        self.rin_ability_until = 0
        self.rin_ability_user = None
        self.shield_blue_until = 0
        self.shield_red_until = 0
        self.isagi_dim_until = 0

        self.keys = set()
        if not self.ai_mode:
            self.root.bind("<KeyPress>", self.press)
            self.root.bind("<KeyRelease>", self.release)
        self.root.bind("<Escape>", lambda e: self.exit_to_menu())

        self.update()

    def play_game_sound(self, name):
        """Воспроизведение звука с учётом настроек игры"""
        if self.game_sound_enabled:
            play_sound(name)

    def stop_game_sound(self, name):
        """Остановка звука с учётом настроек игры"""
        if self.game_sound_enabled:
            stop_sound(name)

    def create_exit_button(self):
        self.exit_btn = tk.Button(
            self.root, text="✕ В МЕНЮ", bg="#8b0000", fg="white",
            font=("Arial", 14, "bold"), relief="raised", bd=3,
            command=self.exit_to_menu,
            activebackground="#ff0000", activeforeground="white"
        )
        self.exit_btn.place(x=10, y=10)
        self.exit_btn.bind("<Enter>", lambda e: self.exit_btn.configure(bg="#cc0000"))
        self.exit_btn.bind("<Leave>", lambda e: self.exit_btn.configure(bg="#8b0000"))

    def create_debug_button(self):
        self.debug_btn = tk.Button(
            self.root, text="🔧 ОТЛАДКА", bg="#2d2d2d", fg="#00ff00",
            font=("Arial", 12, "bold"), relief="raised", bd=3,
            command=self.toggle_debug_menu,
            activebackground="#4d4d4d", activeforeground="#00ff00"
        )
        self.debug_btn.place(x=10, y=55)
        self.debug_btn.bind("<Enter>", lambda e: self.debug_btn.configure(bg="#3d3d3d"))
        self.debug_btn.bind("<Leave>", lambda e: self.debug_btn.configure(bg="#2d2d2d"))

        self.debug_panel = tk.Frame(self.root, bg="#1a1a1a", bd=2, relief="raised")
        self.debug_panel_visible = False

        self.cooldown_btn = tk.Button(
            self.debug_panel, text="🔄 КД: ВКЛ", bg="#1a3a1a", fg="#00ff00",
            font=("Arial", 11, "bold"), relief="raised", bd=2,
            command=self.toggle_cooldown,
            activebackground="#2a5a2a", activeforeground="#00ff00"
        )
        self.cooldown_btn.pack(fill="x", padx=5, pady=5)

        self.sound_btn = tk.Button(
            self.debug_panel, text="🔊 ЗВУК: ВКЛ", bg="#1a3a1a", fg="#00ff00",
            font=("Arial", 11, "bold"), relief="raised", bd=2,
            command=self.toggle_sound,
            activebackground="#2a5a2a", activeforeground="#00ff00"
        )
        self.sound_btn.pack(fill="x", padx=5, pady=5)

        tk.Button(self.debug_panel, text="🔄 СБРОС МАТЧА", bg="#1a1a3a", fg="#0088ff",
                  font=("Arial", 11, "bold"), relief="raised", bd=2,
                  command=self.reset_match,
                  activebackground="#2a2a5a", activeforeground="#0088ff").pack(fill="x", padx=5, pady=5)

        tk.Button(self.debug_panel, text="⚽ ГОЛ СИНИМ", bg="#0d47a1", fg="white",
                  font=("Arial", 11, "bold"), relief="raised", bd=2,
                  command=lambda: self.debug_goal("Blue"),
                  activebackground="#1565c0", activeforeground="white").pack(fill="x", padx=5, pady=5)

        tk.Button(self.debug_panel, text="⚽ ГОЛ КРАСНЫМ", bg="#b71c1c", fg="white",
                  font=("Arial", 11, "bold"), relief="raised", bd=2,
                  command=lambda: self.debug_goal("Red"),
                  activebackground="#d32f2f", activeforeground="white").pack(fill="x", padx=5, pady=5)

    def toggle_debug_menu(self):
        if self.debug_panel_visible:
            self.debug_panel.place_forget()
            self.debug_panel_visible = False
        else:
            self.debug_panel.place(x=10, y=95)
            self.debug_panel_visible = True

    def toggle_cooldown(self):
        self.no_cooldown = not self.no_cooldown
        if self.no_cooldown:
            self.cooldown_btn.configure(text="🔄 КД: ВЫКЛ", bg="#3a1a1a", fg="#ff0000")
            self.p1["dash_cd_until"] = 0
            self.p2["dash_cd_until"] = 0
        else:
            self.cooldown_btn.configure(text="🔄 КД: ВКЛ", bg="#1a3a1a", fg="#00ff00")

    def toggle_sound(self):
        self.game_sound_enabled = not self.game_sound_enabled
        if self.game_sound_enabled:
            self.sound_btn.configure(text="🔊 ЗВУК: ВКЛ", bg="#1a3a1a", fg="#00ff00")
        else:
            self.sound_btn.configure(text="🔇 ЗВУК: ВЫКЛ", bg="#3a1a1a", fg="#ff0000")

    def debug_goal(self, side):
        if side == "Blue":
            self.score[0] += 1
        else:
            self.score[1] += 1
        self.goal_text_id = "DEBUG GOAL!"
        self.freeze_until = time.time() + 1.5
        self.play_game_sound("goal")
        self.root.after(1500, self.reset_game)

    def reset_match(self):
        self.score = [0, 0]
        self.freeze_until = 0
        self.time_stop_until = 0
        self.ts_owner = None
        self.ts_factor = 0.0
        self.knives = []
        self.impact_effect = None
        self.puzzle_pieces = []
        self.naruto_particles = []
        self.nagi_particles = []
        self.nagi_void_aura = []
        self.skull_auras = []
        self.hulk_cracks = []
        self.hulk_transform_effects = []
        self.kaiser_petals = []
        for p in [self.p1, self.p2]:
            p["flies"] = []
            p["nagi_hitbox_until"] = 0
            p["naruto_aura_until"] = 0
            p["naruto_kyubi_until"] = 0
            p["naruto_counter_ready"] = False
            p["hulk_scale"] = 1.0
            p["hulk_original_radius"] = CHARACTER_TYPES[p["char_type"]]["base_radius"]
            p["kaiser_aura_until"] = 0
        self.goal_text_id = "СБРОС!"
        self.root.after(1000, self.reset_game)

    def exit_to_menu(self):
        self.running = False
        self.root.destroy()
        self.launch_menu()

    def launch_menu(self):
        m = Menu()
        m.root.mainloop()
        if len(m.selections) == 2:
            game = BlueLockPro2026(m.selections[0], m.selections[1],
                                   getattr(m, 'ai_mode', False),
                                   getattr(m, 'switch_goals', 0))
            game.root.mainloop()

    def create_player(self, x, y, color, char_type, side):
        p = {
            "x": x, "y": y, "start_x": x, "start_y": y, "angle": 0 if side == "Blue" else math.pi, "side": side,
            "color": color,
            "radius": CHARACTER_TYPES[char_type]["base_radius"],
            "base_speed": 9, "dribbling": False, "last_press": 0,
            "dash_cd_until": 0, "boost_until": 0, "stunned_until": 0,
            "snake_until": 0,
            "char_type": char_type,
            "is_dashing": False,
            "dialogue": "", "target_text": "", "last_char_t": 0, "shake_until": 0,
            "rot_until": 0,
            "flies": [],
            "nagi_hitbox_until": 0,
            "naruto_aura_until": 0,
            "naruto_kyubi_until": 0,
            "naruto_counter_ready": False,
            "hulk_scale": 1.0,
            "hulk_original_radius": CHARACTER_TYPES[char_type]["base_radius"],
            "nagi_charge": 0.0 if char_type == "Nagi" else 0.0,
            "skull_active": False,
            "skull_start_t": 0,
            "kaiser_aura_until": 0
        }
        return p

    def spawn_kaiser_petals(self, owner, count=12):
        """Голубые лепестки роз, переходящие в пурпурный"""
        for _ in range(count):
            angle = random.uniform(0, 2 * math.pi)
            speed = random.uniform(1.5, 4.5)
            life = random.uniform(1, 2)
            color_type = random.random()
            if color_type < 0.3:
                color = "#42a5f5"
            elif color_type < 0.6:
                color = "#7e57c2"
            elif color_type < 0.85:
                color = "#5c6bc0"
            else:
                color = "#ab47bc"

            self.kaiser_petals.append({
                "x": owner['x'],
                "y": owner['y'],
                "dx": math.cos(angle) * speed,
                "dy": math.sin(angle) * speed - random.uniform(0.5, 2.0),
                "life": life,
                "max_life": life,
                "size": random.uniform(15, 25),
                "color": color,
                "rotation": random.uniform(0, 360),
                "rot_speed": random.uniform(-3, 3),
                "sway_speed": random.uniform(0.5, 2.0),
                "sway_amount": random.uniform(0.5, 2.5),
                "owner_id": id(owner)
            })

    def spawn_nagi_particles(self, owner, count=8):
        """Разлетающиеся черно-белые частицы"""
        for _ in range(count):
            angle = random.uniform(0, 2 * math.pi)
            speed = random.uniform(2, 5)
            life = random.uniform(0.5, 1.0)
            self.nagi_particles.append({
                "x": owner['x'],
                "y": owner['y'],
                "dx": math.cos(angle) * speed,
                "dy": math.sin(angle) * speed,
                "life": life,
                "max_life": life,
                "size": random.uniform(3, 7),
                "color": random.choice(["#000000", "#333333", "#666666", "#999999", "#CCCCCC", "#FFFFFF"]),
                "owner_id": id(owner)
            })

    def spawn_nagi_void_aura(self, owner, count=10):
        """Фиолетовая аура как у черепа, но больше"""
        for _ in range(count):
            angle = random.uniform(0, 2 * math.pi)
            distance = random.uniform(owner['radius'] * 1.5, owner['radius'] * 3.0)
            self.nagi_void_aura.append({
                "x": owner['x'] + math.cos(angle) * distance,
                "y": owner['y'] + math.sin(angle) * distance,
                "angle": angle,
                "distance": distance,
                "speed": random.uniform(0.03, 0.06) * random.choice([-1, 1]),
                "size": random.uniform(10, 18),
                "life": 1.5,
                "max_life": 1.5,
                "owner_id": id(owner),
                "color": random.choice(["#2a004d", "#3d0066", "#5c0099", "#7b00cc", "#9a00e6"])
            })

    def spawn_skull_aura(self, x, y, count=4):
        """Фиолетовая аура вокруг черепа"""
        for _ in range(count):
            angle = random.uniform(0, 2 * math.pi)
            distance = random.uniform(15, 35)
            self.skull_auras.append({
                "x": x + math.cos(angle) * distance,
                "y": y + math.sin(angle) * distance,
                "angle": angle,
                "distance": distance,
                "speed": random.uniform(0.05, 0.1),
                "size": random.uniform(4, 8),
                "life": 0.6,
                "max_life": 0.6,
                "color": random.choice(["#2a004d", "#3d0066", "#5c0099", "#7b00cc"])
            })

    def spawn_naruto_particles(self, x, y, color="#ff8c00"):
        for _ in range(20):
            angle = random.uniform(0, 2 * math.pi)
            speed = random.uniform(3, 9)
            life = random.uniform(0.6, 1.4)
            size = random.uniform(3, 7)
            self.naruto_particles.append({
                "x": x, "y": y,
                "dx": math.cos(angle) * speed,
                "dy": math.sin(angle) * speed,
                "life": life, "max_life": life,
                "size": size, "color": color,
                "rotation": random.uniform(0, 360),
                "rot_speed": random.uniform(-10, 10)
            })

    def spawn_puzzle_pieces(self, x, y):
        colors = ["#00ffff", "#00bcd4", "#0097a7", "#4dd0e1", "#80deea", "#26c6da", "#00acc1", "#00838f"]
        for _ in range(12):
            angle = random.uniform(0, 2 * math.pi)
            speed = random.uniform(3, 8)
            size = random.uniform(15, 28)
            tabs = [random.choice([-1, 0, 0, 1, 1]) for _ in range(4)]
            piece = {
                "x": x, "y": y,
                "dx": math.cos(angle) * speed,
                "dy": math.sin(angle) * speed,
                "life": 1.0, "size": size,
                "color": random.choice(colors),
                "rotation": random.uniform(0, 360),
                "rot_speed": random.uniform(-8, 8),
                "tabs": tabs
            }
            self.puzzle_pieces.append(piece)

    def draw_puzzle_piece(self, x, y, size, rotation, color, tabs):
        def rotate_point(px, py):
            cos_r = math.cos(math.radians(rotation))
            sin_r = math.sin(math.radians(rotation))
            rx = (px - x) * cos_r - (py - y) * sin_r + x
            ry = (px - x) * sin_r + (py - y) * cos_r + y
            return rx, ry

        tab_width = size * 0.25
        tab_height = size * 0.3
        all_points = []
        all_points.append(rotate_point(x - size, y - size))

        for idx in range(4):
            if tabs[idx] == 0:
                if idx == 0:
                    all_points.append(rotate_point(x + size, y - size))
                elif idx == 1:
                    all_points.append(rotate_point(x + size, y + size))
                elif idx == 2:
                    all_points.append(rotate_point(x - size, y + size))
                else:
                    all_points.append(rotate_point(x - size, y - size))
            else:
                sign = tabs[idx]
                if idx == 0:
                    all_points.append(rotate_point(x - tab_width, y - size))
                    if sign == 1:
                        all_points.append(rotate_point(x - tab_width * 0.7, y - size - tab_height * 0.3))
                        all_points.append(rotate_point(x, y - size - tab_height))
                        all_points.append(rotate_point(x + tab_width * 0.7, y - size - tab_height * 0.3))
                    else:
                        all_points.append(rotate_point(x - tab_width * 0.7, y - size + tab_height * 0.3))
                        all_points.append(rotate_point(x, y - size + tab_height))
                        all_points.append(rotate_point(x + tab_width * 0.7, y - size + tab_height * 0.3))
                    all_points.append(rotate_point(x + tab_width, y - size))
                    all_points.append(rotate_point(x + size, y - size))
                elif idx == 1:
                    all_points.append(rotate_point(x + size, y - tab_width))
                    if sign == 1:
                        all_points.append(rotate_point(x + size + tab_height * 0.3, y - tab_width * 0.7))
                        all_points.append(rotate_point(x + size + tab_height, y))
                        all_points.append(rotate_point(x + size + tab_height * 0.3, y + tab_width * 0.7))
                    else:
                        all_points.append(rotate_point(x + size - tab_height * 0.3, y - tab_width * 0.7))
                        all_points.append(rotate_point(x + size - tab_height, y))
                        all_points.append(rotate_point(x + size - tab_height * 0.3, y + tab_width * 0.7))
                    all_points.append(rotate_point(x + size, y + tab_width))
                    all_points.append(rotate_point(x + size, y + size))
                elif idx == 2:
                    all_points.append(rotate_point(x + tab_width, y + size))
                    if sign == 1:
                        all_points.append(rotate_point(x + tab_width * 0.7, y + size + tab_height * 0.3))
                        all_points.append(rotate_point(x, y + size + tab_height))
                        all_points.append(rotate_point(x - tab_width * 0.7, y + size + tab_height * 0.3))
                    else:
                        all_points.append(rotate_point(x + tab_width * 0.7, y + size - tab_height * 0.3))
                        all_points.append(rotate_point(x, y + size - tab_height))
                        all_points.append(rotate_point(x - tab_width * 0.7, y + size - tab_height * 0.3))
                    all_points.append(rotate_point(x - tab_width, y + size))
                    all_points.append(rotate_point(x - size, y + size))
                else:
                    all_points.append(rotate_point(x - size, y + tab_width))
                    if sign == 1:
                        all_points.append(rotate_point(x - size - tab_height * 0.3, y + tab_width * 0.7))
                        all_points.append(rotate_point(x - size - tab_height, y))
                        all_points.append(rotate_point(x - size - tab_height * 0.3, y - tab_width * 0.7))
                    else:
                        all_points.append(rotate_point(x - size + tab_height * 0.3, y + tab_width * 0.7))
                        all_points.append(rotate_point(x - size + tab_height, y))
                        all_points.append(rotate_point(x - size + tab_height * 0.3, y - tab_width * 0.7))
                    all_points.append(rotate_point(x - size, y - tab_width))
                    all_points.append(rotate_point(x - size, y - size))

        flat_points = []
        for px, py in all_points:
            flat_points.extend([px, py])

        if len(flat_points) >= 6:
            shadow_points = []
            for i in range(0, len(flat_points), 2):
                shadow_points.extend([flat_points[i] + 2, flat_points[i + 1] + 2])
            self.canvas.create_polygon(shadow_points, fill="#000000", outline="", smooth=True)
            self.canvas.create_polygon(flat_points, fill=color, outline="#ffffff", width=1.5, smooth=True)

    def press(self, e):
        k = e.keysym
        k_lower = k.lower()
        is_repeat = (k_lower in self.keys) or (k in self.keys)
        self.keys.add(k_lower)
        self.keys.add(k)

        if time.time() < self.freeze_until: return
        now = time.time()

        if not is_repeat:
            if k_lower == 'w':
                if now - self.p1["last_press"] < 0.35: self.activate_dash(self.p1)
                self.p1["last_press"] = now
            if k == 'Up':
                if now - self.p2["last_press"] < 0.35: self.activate_dash(self.p2)
                self.p2["last_press"] = now
            if k_lower == 'space': self.kick(self.p1)
            if k == 'Control_R': self.kick(self.p2)

    def release(self, e):
        self.keys.discard(e.keysym.lower())
        self.keys.discard(e.keysym)

    def kick(self, p):
        now = time.time()
        if not p['dribbling'] or now < self.freeze_until: return

        power = 42
        if p["char_type"] == "Kaiser": power = 58
        if p["char_type"] == "Isagi" and now < p['boost_until']: power = 46
        if p["char_type"] == "Naruto" and now < p.get("naruto_kyubi_until", 0): power = 62

        self.ball['dribbler'] = None
        p['dribbling'] = False
        self.ball['kick_t'] = now
        self.last_scorer = p

        if p["char_type"] == "Kaiser":
            self.play_game_sound("kick")
        elif p["char_type"] == "Rin" and now < self.rin_ability_until and self.rin_ability_user == p:
            self.play_game_sound("kick")
        else:
            self.play_game_sound("kick")

        if now < self.rin_ability_until and p["char_type"] == "Rin" and self.rin_ability_user == p:
            power = 55
            base_angle = p['angle']
            self.ball['dx'] = math.cos(base_angle) * power
            self.ball['dy'] = math.sin(base_angle) * power
            self.ball['curve'] = -1.5
            self.ball['rin_kicker'] = p
        else:
            self.ball['dx'] = math.cos(p['angle']) * power
            self.ball['dy'] = math.sin(p['angle']) * power
            self.ball['curve'] = 0
            self.ball['rin_kicker'] = None

    def show_warning_text(self, p, text):
        offset = 65 if p["char_type"] in ["Nagi", "Dio", "Naruto"] else 35
        self.active_warning = {"text": text, "player": p, "until": time.time() + 2.5, "offset": offset}

    def show_nagi_hitbox(self, p, now):
        p["nagi_hitbox_until"] = now + 1.0

    def deactivate_isagi_ability(self, p):
        p['boost_until'] = 0
        self.isagi_dim_until = 0
        if p['side'] == "Blue":
            self.shield_blue_until = 0
        else:
            self.shield_red_until = 0

    def activate_dash(self, p):
        now = time.time()
        ctype = p["char_type"]

        if not self.no_cooldown:
            if ctype not in ["Aiku", "Nagi", "Dio", "Naruto"] and (
                    now < p["dash_cd_until"] or now < p["stunned_until"]): return
            if ctype in ["Aiku", "Dio", "Naruto"] and (now < p["dash_cd_until"] or now < p["stunned_until"]): return

        if ctype == "Naruto":
            if not p['dribbling']:
                if not self.ai_mode: self.show_warning_text(p, "Нужен мяч для ауры!")
                return
            p["dash_cd_until"] = now + CHARACTER_TYPES[ctype]["cd"] if not self.no_cooldown else 0
            p["naruto_aura_until"] = now + 4.0
            p["naruto_counter_ready"] = True
            p["target_text"] = "Расенган!"
            p["dialogue"] = ""
            p["last_char_t"] = now
            return

        elif ctype == "Nagi":
            if now < p["stunned_until"]: return

            if 0.5 <= p["nagi_charge"] < 0.99:
                if not self.no_cooldown and now < p["dash_cd_until"]:
                    if not self.ai_mode: self.show_warning_text(p, f"КД: {int(p['dash_cd_until'] - now)}с")
                    return
                dist_to_ball = math.hypot(p['x'] - self.ball['x'], p['y'] - self.ball['y'])
                if self.ball['dribbler'] is not None:
                    if not self.ai_mode: self.show_warning_text(p, "Мяч должен быть свободен!")
                    self.show_nagi_hitbox(p, now)
                    return
                if dist_to_ball > 200:
                    if not self.ai_mode: self.show_warning_text(p, "Мяч слишком далеко!")
                    self.show_nagi_hitbox(p, now)
                    return
                p["nagi_charge"] = max(0, p["nagi_charge"] - 0.5)
                p["dash_cd_until"] = now + 12.0 if not self.no_cooldown else 0
                self.play_game_sound("black_hole")
                self.spawn_nagi_particles(p, 10)
                self.spawn_nagi_void_aura(p, 12)
                self.perform_black_hole_trap(p)

            elif p["nagi_charge"] >= 0.99:
                if not self.no_cooldown and now < p["dash_cd_until"]:
                    if not self.ai_mode: self.show_warning_text(p, f"КД: {int(p['dash_cd_until'] - now)}с")
                    return
                if math.hypot(p['x'] - self.ball['x'], p['y'] - self.ball['y']) > 80:
                    if not self.ai_mode: self.show_warning_text(p, "Нужен мяч!")
                    return
                p["nagi_charge"] = 0.0
                p["dash_cd_until"] = now + 15.0 if not self.no_cooldown else 0
                self.play_game_sound("revolver")
                self.spawn_nagi_particles(p, 14)
                self.spawn_nagi_void_aura(p, 16)
                self.perform_nagi_revolver(p)
            else:
                p["shake_until"] = now + 0.4

        elif ctype == "Dio":
            p["dash_cd_until"] = now + 20.0 if not self.no_cooldown else 0
            if p['dribbling']:
                self.play_game_sound("checkmate")
                self.play_game_sound("time_stop")
                self.perform_dio_checkmate(p)
            else:
                self.play_game_sound("time_stop")
                self.time_stop_until = now + 5.0
                self.ts_owner = p
                p["target_text"] = "The World!"
                p["last_char_t"] = now

        elif ctype == "Kaiser":
            if not p['dribbling']:
                if not self.ai_mode: self.show_warning_text(p, "Только с мячом")
                return
            p['dash_cd_until'] = now + CHARACTER_TYPES[ctype]["cd"] if not self.no_cooldown else 0
            self.play_game_sound("kaiser_dribble")
            p['stunned_until'] = now + 0.9
            p['is_dashing'] = True
            p['kaiser_aura_until'] = now + 0.9
            base_angle = p['angle']
            dash_dist = 280
            self.spawn_kaiser_petals(p, 8)
            self.root.after(50, lambda: self.smooth_dash(p, base_angle - 0.7, dash_dist))
            self.root.after(400, lambda: self.smooth_dash(p, base_angle + 0.7,
                                                          dash_dist) if self.freeze_until < time.time() else None)
            self.root.after(900, lambda: p.__setitem__('is_dashing', False))

        elif ctype == "Hulk":
            p['dash_cd_until'] = now + CHARACTER_TYPES[ctype]["cd"] if not self.no_cooldown else 0
            p['boost_until'] = now + 4.0
            p['hulk_scale'] = 1.0
            p['hulk_original_radius'] = CHARACTER_TYPES["Hulk"]["base_radius"]

            self.play_game_sound("hulk_transform")

            opp = self.p2 if p == self.p1 else self.p1
            dist_to_opp = math.hypot(p['x'] - opp['x'], p['y'] - opp['y'])
            if dist_to_opp < 300:
                angle_to_opp = math.atan2(opp['y'] - p['y'], opp['x'] - p['x'])
                opp['x'] += math.cos(angle_to_opp) * 50
                opp['y'] += math.sin(angle_to_opp) * 50
                opp['stunned_until'] = now + 0.5

            for _ in range(9):
                crack_angle = random.uniform(0, 2 * math.pi)
                crack_length = random.uniform(180, 250)
                self.hulk_cracks.append({
                    "x": p['x'],
                    "y": p['y'],
                    "angle": crack_angle,
                    "length": crack_length,
                    "life": 2.0,
                    "segments": random.randint(2, 4)
                })

            for _ in range(20):
                angle = random.uniform(0, 2 * math.pi)
                speed = random.uniform(2, 5)
                self.hulk_transform_effects.append({
                    "x": p['x'],
                    "y": p['y'],
                    "dx": math.cos(angle) * speed,
                    "dy": math.sin(angle) * speed,
                    "life": 1.0,
                    "color": random.choice(["#2e7d32", "#4caf50", "#81c784", "#a5d6a7"])
                })

            p["target_text"] = "HULK SMASH!"
            p["dialogue"] = ""
            p["last_char_t"] = now

        elif ctype == "Isagi":
            p['dash_cd_until'] = now + CHARACTER_TYPES[ctype]["cd"] if not self.no_cooldown else 0
            p['boost_until'] = now + 2.5
            self.isagi_dim_until = now + 2.5
            if p['side'] == "Blue":
                self.shield_blue_until = now + 2.5
            else:
                self.shield_red_until = now + 2.5
            self.play_game_sound("meta_vision")

        elif ctype == "Rin":
            self.play_game_sound("rin")
            p['dash_cd_until'] = now + CHARACTER_TYPES[ctype]["cd"] if not self.no_cooldown else 0
            p['boost_until'] = now + 3.0
            self.rin_ability_until = now + 4.0
            self.rin_ability_user = p
            if p['side'] == "Blue":
                self.gy1_red = self.sh // 2 - (self.gh_base + 120) // 2
                self.gy2_red = self.sh // 2 + (self.gh_base + 120) // 2
            else:
                self.gy1_blue = self.sh // 2 - (self.gh_base + 120) // 2
                self.gy2_blue = self.sh // 2 + (self.gh_base + 120) // 2
            opp = self.p2 if p == self.p1 else self.p1
            if math.hypot(p['x'] - opp['x'], p['y'] - opp['y']) < 200:
                opp['stunned_until'] = now + 1.5


        elif ctype == "Pudge":

            p['dash_cd_until'] = now + CHARACTER_TYPES[ctype]["cd"] if not self.no_cooldown else 0

            if p['dribbling']:

                p["rot_until"] = now + 3.0

                self.play_game_sound("rot")

                p["flies"] = []

                for _ in range(15):
                    angle = random.uniform(0, 2 * math.pi)

                    dist = random.uniform(40, 100)

                    p["flies"].append({

                        "angle": angle, "dist": dist,

                        "speed": random.uniform(0.5, 2.0),

                        "size": random.uniform(3, 6),

                        "wobble_offset": random.uniform(0, 2 * math.pi),

                        "wobble_speed": random.uniform(0.05, 0.15)

                    })

            else:

                # Не останавливаем hook если он уже активен, просто не запускаем новый

                if not self.hook["active"]:
                    self.play_game_sound("hook")

                    self.hook.update({"active": True, "x": p['x'], "y": p['y'],

                                      "dx": math.cos(p['angle']) * 28, "dy": math.sin(p['angle']) * 28,

                                      "owner": p, "target": None, "dist": 0})

        elif ctype == "Aiku":
            is_blue = (p['side'] == "Blue")
            ball_in_own_half = (is_blue and self.ball['x'] < self.sw // 2) or (
                    not is_blue and self.ball['x'] > self.sw // 2)
            aiku_in_own_half = (is_blue and p['x'] < self.sw // 2) or (not is_blue and p['x'] > self.sw // 2)
            if ball_in_own_half and aiku_in_own_half and self.ball['dribbler'] is None:
                p['dash_cd_until'] = now + CHARACTER_TYPES[ctype]["cd"] if not self.no_cooldown else 0
                p['snake_until'] = now + 2
                self.play_game_sound("snake")
                p['x'], p['y'] = self.ball['x'], self.ball['y']
                self.ball['dx'] = self.ball['dy'] = 0
                self.ball['curve'] = 0
                self.ball['rin_kicker'] = None
                self.freeze_until = now + 2
            else:
                if not self.ai_mode:
                    if not aiku_in_own_half:
                        self.show_warning_text(p, "Вернись в защиту!")
                    else:
                        self.show_warning_text(p, "Мяч должен быть на своей половине")
                return

    def deactivate_nagi_skull(self, p):
        p["skull_active"] = False
        p["skull_start_t"] = 0

    def perform_black_hole_trap(self, p):
        self.freeze_until = time.time() + 1.5
        start_x, start_y = p['x'], p['y']
        target_x, target_y = self.ball['x'], self.ball['y']
        p["skull_active"] = True
        p["skull_start_t"] = time.time()
        enemy_goal_x = self.sw if p['side'] == "Blue" else 0
        p['angle'] = math.atan2(self.sh // 2 - p['y'], enemy_goal_x - p['x'])

        def animate_trap(step):
            if step > 25:
                p['x'] = target_x
                p['y'] = target_y
                self.ball['dribbler'] = p
                p['dribbling'] = True
                self.ball['x'] = p['x'] + math.cos(p['angle']) * (p['radius'] + self.ball['radius'] + 2)
                self.ball['y'] = p['y'] + math.sin(p['angle']) * (p['radius'] + self.ball['radius'] + 2)
                opp = self.p2 if p == self.p1 else self.p1
                if math.hypot(p['x'] - opp['x'], p['y'] - opp['y']) < 150:
                    opp['stunned_until'] = time.time() + 0.8
                self.root.after(1500, self.deactivate_nagi_skull, p)
                self.freeze_until = 0
                p["skull_start_t"] = 0
                return
            if step <= 10:
                progress = step / 10
                p['x'] = start_x + math.sin(progress * math.pi * 2) * 5
                p['y'] = start_y + math.cos(progress * math.pi * 2) * 5
            else:
                progress = (step - 10) / 15
                eased = 1 - math.pow(1 - progress, 3)
                p['x'] = start_x + (target_x - start_x) * eased
                p['y'] = start_y + (target_y - start_y) * eased
            self.root.after(40, lambda: animate_trap(step + 1))

        animate_trap(0)

    def perform_dio_checkmate(self, p):
        self.freeze_until = time.time() + 3.5
        self.time_stop_until = time.time() + 2.5
        self.ts_owner = p
        self.ball['dribbler'] = None
        p['dribbling'] = False
        self.ball['curve'] = 0
        self.ball['rin_kicker'] = None
        p['dialogue'] = ""
        p['target_text'] = "Checkmate."
        p['last_char_t'] = time.time()
        start_x, start_y = p['x'], p['y']
        back_angle = p['angle'] + math.pi

        def step_back(i):
            if i > 20:
                spawn_knives()
                return
            progress = i / 20
            ease = math.sin(progress * math.pi / 2)
            dist = 60 * ease
            p['x'] = start_x + math.cos(back_angle) * dist
            p['y'] = start_y + math.sin(back_angle) * dist
            self.root.after(30, lambda: step_back(i + 1))

        def spawn_knives():
            base_angle = p['angle']
            spread = math.radians(135)
            start_angle = base_angle - spread / 2
            num_knives = 7
            for k in range(num_knives):
                ang = start_angle + (spread * (k / (num_knives - 1)))
                spawn_dist = 40
                kx = self.ball['x'] - math.cos(base_angle) * 20 + math.cos(ang + math.pi) * spawn_dist
                ky = self.ball['y'] - math.sin(base_angle) * 20 + math.sin(ang + math.pi) * spawn_dist
                self.knives.append({
                    "x": kx, "y": ky,
                    "dx": math.cos(base_angle) * 0,
                    "dy": math.sin(base_angle) * 0,
                    "angle": base_angle,
                    "owner": p,
                    "frozen": True
                })
            self.root.after(800, final_kick)

        def final_kick():
            self.knives = []
            self.impact_effect = {"x": self.ball['x'], "y": self.ball['y'], "r": 5, "alpha": 1.0}
            self.time_stop_until = 0
            self.freeze_until = 0
            kp = 75
            self.play_game_sound("kick")
            self.ball['dx'] = math.cos(p['angle']) * kp
            self.ball['dy'] = math.sin(p['angle']) * kp
            self.ball['kick_t'] = time.time()
            self.last_scorer = p

        step_back(0)

    def perform_nagi_revolver(self, p):
        self.freeze_until = time.time() + 5.0
        p['dribbling'] = True
        self.ball['dribbler'] = p
        self.ball['curve'] = 0
        self.ball['rin_kicker'] = None
        cx, cy, angle = p['x'], p['y'], p['angle']
        dist = 60
        targets = [
            (cx + math.cos(angle - math.pi / 2) * dist, cy + math.sin(angle - math.pi / 2) * dist),
            (cx + math.cos(angle + math.pi / 2) * dist, cy + math.sin(angle + math.pi / 2) * dist),
            (cx + math.cos(angle + math.pi) * dist, cy + math.sin(angle + math.pi) * dist),
            (cx + math.cos(angle + math.pi) * (dist + 40), cy + math.sin(angle + math.pi) * (dist + 40)),
            (cx, cy)
        ]

        def run_step(step_idx):
            if step_idx >= len(targets):
                kp = 85
                self.play_game_sound("kick")
                self.ball['dx'] = math.cos(p['angle']) * kp
                self.ball['dy'] = math.sin(p['angle']) * kp
                self.ball['kick_t'] = time.time()
                self.ball['dribbler'] = None
                p['dribbling'] = False
                p["skull_active"] = False
                self.last_scorer = p
                self.freeze_until = 0
                return
            if step_idx == 2:
                p['target_text'] = "Спасибо, Исаги..."
                p['dialogue'] = ""
                p['last_char_t'] = time.time()
            elif step_idx == 3:
                p["skull_active"] = True
                p["skull_start_t"] = time.time()
                p['target_text'] = "Я..."
                p['dialogue'] = ""
                p['last_char_t'] = time.time()
            elif step_idx == 4:
                p['target_text'] = "Лучший в мире."
                p['dialogue'] = ""
                p['last_char_t'] = time.time()
            tx, ty = targets[step_idx]
            start_x, start_y = p['x'], p['y']
            frames, interval = 14, 25

            def animate(f):
                if f > frames:
                    next_delay = 1200 if step_idx == 2 else 250
                    self.root.after(next_delay, lambda: run_step(step_idx + 1))
                    return
                progress_raw = f / frames
                progress_eased = math.sin(progress_raw * math.pi / 2)
                p['x'] = start_x + (tx - start_x) * progress_eased
                p['y'] = start_y + (ty - start_y) * progress_eased
                self.ball['x'] = p['x'] + math.cos(p['angle']) * (p['radius'] + 5)
                self.ball['y'] = p['y'] + math.sin(p['angle']) * (p['radius'] + 5)
                self.root.after(interval, lambda: animate(f + 1))

            animate(1)

        run_step(0)

    def smooth_dash(self, p, angle, total_dist):
        step_dist = 22
        steps = int(total_dist / step_dist)

        def do_step(current_step):
            if current_step >= steps or self.freeze_until > time.time(): return
            p['x'] += math.cos(angle) * step_dist
            p['y'] += math.sin(angle) * step_dist
            p['x'] = max(p['radius'], min(self.sw - p['radius'], p['x']))
            p['y'] = max(p['radius'], min(self.sh - p['radius'], p['y']))
            if p['dribbling']:
                self.ball['x'] = p['x'] + math.cos(p['angle']) * (p['radius'] + 20)
                self.ball['y'] = p['y'] + math.sin(p['angle']) * (p['radius'] + 20)
            p['boost_until'] = time.time() + 0.1
            self.root.after(10, lambda: do_step(current_step + 1))

        do_step(0)

    def process_ai(self, p, opp, side):
        now = time.time()
        is_time_stopped = (now < self.time_stop_until)

        if is_time_stopped and p != self.ts_owner and p["char_type"] != "Dio": return
        if now < self.freeze_until and not is_time_stopped: return
        if now < p["stunned_until"]: return

        b = self.ball
        goal_x = self.sw if side == "Blue" else 0
        gk = self.gk_red if side == "Blue" else self.gk_blue
        goal_y_top = self.gy1_red if side == "Blue" else self.gy1_blue
        goal_y_bot = self.gy2_red if side == "Blue" else self.gy2_blue

        target_x, target_y = b['x'], b['y']
        dist_to_goal = math.hypot(p['x'] - goal_x, p['y'] - self.sh // 2)
        dist_to_opp = math.hypot(p['x'] - opp['x'], p['y'] - opp['y'])

        if p['dribbling']:
            if gk['y'] > self.sh // 2:
                best_aim_y = goal_y_top + 60
            else:
                best_aim_y = goal_y_bot - 60
            target_x, target_y = goal_x, best_aim_y
            angle_to_target = math.atan2(target_y - p['y'], target_x - p['x'])
            angle_diff = abs((angle_to_target - p['angle'] + math.pi) % (2 * math.pi) - math.pi)
            if dist_to_goal < 420 and angle_diff < 0.35:
                self.kick(p)

        angle_to_target = math.atan2(target_y - p['y'], target_x - p['x'])
        diff = angle_to_target - p['angle']
        diff = (diff + math.pi) % (2 * math.pi) - math.pi

        if diff > 0.15:
            p['angle'] += 0.15
        elif diff < -0.15:
            p['angle'] -= 0.15

        speed = p['base_speed']
        if p["char_type"] == "Isagi" and now < p['boost_until']:
            speed *= 1.8
        if p['dribbling']:
            speed *= 0.7
        if p["char_type"] == "Naruto" and now < p.get("naruto_kyubi_until", 0): speed *= 1.5
        if is_time_stopped and p != self.ts_owner: speed *= 0.3

        if opp["char_type"] == "Pudge" and now < opp.get("rot_until", 0):
            if math.hypot(p['x'] - opp['x'], p['y'] - opp['y']) < 140:
                speed *= 0.35

        if p["char_type"] != "Hulk":
            hulk_slow = 1.0
            for crack in self.hulk_cracks:
                if crack["life"] > 0:
                    dist = math.hypot(p['x'] - crack['x'], p['y'] - crack['y'])
                    if dist < crack["length"]:
                        hulk_slow = 0.5
                        break
            speed *= hulk_slow

        p['x'] += math.cos(p['angle']) * speed
        p['y'] += math.sin(p['angle']) * speed

        if (self.no_cooldown or now > p["dash_cd_until"]) and not self.hook["active"]:
            ctype = p["char_type"]
            opp_has_ball = (b['dribbler'] == opp)
            use_ability = False

            if ctype == "Naruto" and p['dribbling'] and now >= p.get("naruto_aura_until", 0):
                use_ability = True
            elif ctype == "Nagi" and p.get("nagi_charge", 0) >= 0.5:
                use_ability = True
            elif ctype == "Kaiser" and p['dribbling']:
                if 200 < dist_to_goal < 550: use_ability = True
            elif ctype == "Aiku":
                ball_in_own_half = (side == "Blue" and b['x'] < self.sw // 2) or (
                        side == "Red" and b['x'] > self.sw // 2)
                if ball_in_own_half and not p['dribbling']: use_ability = True
            elif ctype == "Hulk":
                if dist_to_opp < 180 or (p['dribbling'] and dist_to_opp < 250): use_ability = True
            elif ctype == "Isagi":
                if opp_has_ball or (p['dribbling'] and dist_to_opp < 200): use_ability = True
            elif ctype == "Rin":
                if p['dribbling'] and dist_to_goal < 450: use_ability = True
            elif ctype == "Pudge":
                if p['dribbling'] or (not p['dribbling'] and opp_has_ball and dist_to_opp < 450): use_ability = True
            elif ctype == "Dio":
                if p['dribbling'] and dist_to_goal < 350:
                    use_ability = True
                elif opp_has_ball and dist_to_opp < 350:
                    use_ability = True

            if use_ability:
                self.activate_dash(p)

        p['x'] = max(p['radius'], min(self.sw - p['radius'], p['x']))
        p['y'] = max(p['radius'], min(self.sh - p['radius'], p['y']))
        if p["char_type"] == "Hulk" and now < p['boost_until']:
            if p.get('hulk_scale', 1.0) < 2.0:
                p['hulk_scale'] = min(2.0, p['hulk_scale'] + 0.2)
            target_radius = p.get('hulk_original_radius', 45) * p['hulk_scale']
            p['radius'] += (target_radius - p['radius']) * 1
        elif p["char_type"] == "Hulk":
            p["radius"] = CHARACTER_TYPES["Hulk"]["base_radius"]

    def move_player(self, p, up, down, left, right):
        now = time.time()
        is_time_stopped = (now < self.time_stop_until)

        if is_time_stopped:
            if p == self.ts_owner or p["char_type"] == "Dio":
                pass
            else:
                return

        if now < self.freeze_until and not is_time_stopped: return
        if now < p["stunned_until"]: return

        speed = p['base_speed']
        if p["char_type"] == "Isagi" and now < p['boost_until']:
            speed *= 1.8
        if p['dribbling']:
            speed *= 0.7
        if p["char_type"] == "Naruto" and now < p.get("naruto_kyubi_until", 0): speed *= 1.5
        if is_time_stopped and p != self.ts_owner: speed *= 0.3

        other = self.p2 if p == self.p1 else self.p1
        if other["char_type"] == "Pudge" and now < other.get("rot_until", 0):
            if math.hypot(p['x'] - other['x'], p['y'] - other['y']) < 140:
                speed *= 0.35

        hulk_slow = 1.0
        for crack in self.hulk_cracks:
            if crack["life"] > 0:
                dist = math.hypot(p['x'] - crack['x'], p['y'] - crack['y'])
                if dist < crack["length"]:
                    hulk_slow = 0.5
                    break
        speed *= hulk_slow

        if left in self.keys: p['angle'] -= 0.15
        if right in self.keys: p['angle'] += 0.15

        if up in self.keys:
            p['x'] += math.cos(p['angle']) * speed
            p['y'] += math.sin(p['angle']) * speed
        if down in self.keys:
            p['x'] -= math.cos(p['angle']) * (speed * 0.6)
            p['y'] -= math.sin(p['angle']) * (speed * 0.6)

        p['x'] = max(p['radius'], min(self.sw - p['radius'], p['x']))
        p['y'] = max(p['radius'], min(self.sh - p['radius'], p['y']))
        if p["char_type"] == "Hulk" and now < p['boost_until']:
            if p.get('hulk_scale', 1.0) < 2.0:
                p['hulk_scale'] = min(2.0, p['hulk_scale'] + 0.20)
            target_radius = p.get('hulk_original_radius', 45) * p['hulk_scale']
            p['radius'] += (target_radius - p['radius']) * 1
        elif p["char_type"] == "Hulk":
            p["radius"] = CHARACTER_TYPES["Hulk"]["base_radius"]

    def move_gk(self):
        now = time.time()
        if now < self.freeze_until or now < self.time_stop_until: return
        gk_speed = 0.35
        self.gk_blue['y'] += ((self.ball['y'] if self.ball['x'] < self.sw // 2 else self.p2['y']) - self.gk_blue[
            'y']) * gk_speed
        self.gk_blue['y'] = max(self.gy1_blue + self.gk_blue['radius'],
                                min(self.gy2_blue - self.gk_blue['radius'], self.gk_blue['y']))
        self.gk_red['y'] += ((self.ball['y'] if self.ball['x'] > self.sw // 2 else self.p1['y']) - self.gk_red[
            'y']) * gk_speed
        self.gk_red['y'] = max(self.gy1_red + self.gk_red['radius'],
                               min(self.gy2_red - self.gk_red['radius'], self.gk_red['y']))

    def draw_skull(self, x, y, scale, now):
        """Простой череп с фиолетовой аурой"""
        sz = 20 * scale

        self.canvas.create_oval(x - sz - 8, y - sz - 8, x + sz + 8, y + sz + 8,
                                fill="#1a0033", outline="", stipple="gray50")
        self.canvas.create_oval(x - sz - 3, y - sz - 3, x + sz + 3, y + sz + 3,
                                fill="#2d004d", outline="", stipple="gray25")

        self.canvas.create_oval(x - sz, y - sz, x + sz, y + sz,
                                fill="#DDDDDD", outline="#888888", width=2)

        eye_size = sz * 0.3
        eye_offset = sz * 0.35
        eye_y = y - sz * 0.15

        for ex in [-eye_offset, eye_offset]:
            self.canvas.create_oval(x + ex - eye_size, eye_y - eye_size,
                                    x + ex + eye_size, eye_y + eye_size,
                                    fill="#111111", outline="#555555", width=1)
            pupil_size = eye_size * 0.3
            self.canvas.create_oval(x + ex - pupil_size, eye_y - pupil_size,
                                    x + ex + pupil_size, eye_y + pupil_size,
                                    fill="#FFFFFF", outline="")

        nose_size = sz * 0.2
        self.canvas.create_polygon(
            x, y + nose_size * 0.3,
               x - nose_size, y + nose_size * 1.3,
               x + nose_size, y + nose_size * 1.3,
            fill="#111111", outline=""
        )

        tooth_width = sz * 0.12
        for i in range(3):
            tx = x - sz * 0.2 + i * tooth_width * 1.8
            self.canvas.create_rectangle(tx, y + sz * 0.45,
                                         tx + tooth_width, y + sz * 0.6,
                                         fill="#DDDDDD", outline="#888888", width=1)

    def draw_football(self, x, y, radius, rotation=0):
        self.canvas.create_oval(x - radius, y - radius, x + radius, y + radius,
                                fill="white", outline="#333333", width=2)
        pent_radius = radius * 0.38
        pent_points = []
        for i in range(5):
            angle = rotation + (i * 2 * math.pi / 5) - math.pi / 2
            px = x + math.cos(angle) * pent_radius
            py = y + math.sin(angle) * pent_radius
            pent_points.append(px)
            pent_points.append(py)
        self.canvas.create_polygon(pent_points, fill="#1a1a1a", outline="#333333", width=1.5)
        small_pent_radius = radius * 0.2
        edge_distance = radius * 0.72
        for i in range(5):
            base_angle = rotation + (i * 2 * math.pi / 5) - math.pi / 2
            cx = x + math.cos(base_angle) * edge_distance
            cy = y + math.sin(base_angle) * edge_distance
            sp_points = []
            for j in range(5):
                angle = base_angle + math.pi + (j * 2 * math.pi / 5)
                px = cx + math.cos(angle) * small_pent_radius
                py = cy + math.sin(angle) * small_pent_radius
                sp_points.append(px)
                sp_points.append(py)
            self.canvas.create_polygon(sp_points, fill="#1a1a1a", outline="#333333", width=1)
        for i in range(5):
            angle = rotation + (i * 2 * math.pi / 5) - math.pi / 2
            x1 = x + math.cos(angle) * pent_radius
            y1 = y + math.sin(angle) * pent_radius
            x2 = x + math.cos(angle) * (radius * 0.9)
            y2 = y + math.sin(angle) * (radius * 0.9)
            self.canvas.create_line(x1, y1, x2, y2, fill="#999999", width=1)

    def draw_naruto_aura(self, p, now):
        if now >= p.get("naruto_aura_until", 0) and now >= p.get("naruto_kyubi_until", 0):
            return

        is_kyubi = now < p.get("naruto_kyubi_until", 0)
        num_tails = 9 if is_kyubi else 4

        def blend_with_bg(hex_color, opacity):
            bg_color = "#007539"
            rgb_fg = hex_to_rgb(hex_color)
            rgb_bg = hex_to_rgb(bg_color)
            r = int(rgb_fg[0] * opacity + rgb_bg[0] * (1 - opacity))
            g = int(rgb_fg[1] * opacity + rgb_bg[1] * (1 - opacity))
            b = int(rgb_fg[2] * opacity + rgb_bg[2] * (1 - opacity))
            return rgb_to_hex((r, g, b))

        if is_kyubi:
            aura_layers = [
                (p['radius'] + 80, "#ff3d00", 0.15),
                (p['radius'] + 60, "#ff5722", 0.25),
                (p['radius'] + 45, "#ff7043", 0.35),
                (p['radius'] + 30, "#ff8a65", 0.45),
            ]
        else:
            aura_layers = [
                (p['radius'] + 70, "#ff6d00", 0.15),
                (p['radius'] + 50, "#ff8f00", 0.25),
                (p['radius'] + 35, "#ffa726", 0.35),
                (p['radius'] + 22, "#ffb74d", 0.45),
            ]

        pulse = 1 + math.sin(now * 2.5) * 0.03

        for radius, color, opacity in aura_layers:
            r = radius * pulse
            blended_color = blend_with_bg(color, opacity)
            self.canvas.create_oval(
                p['x'] - r, p['y'] - r,
                p['x'] + r, p['y'] + r,
                fill=blended_color, outline=""
            )

        glow_radius = p['radius'] + 18
        glow_color = blend_with_bg("#ffcc80" if is_kyubi else "#ffe0b2", 0.5)
        self.canvas.create_oval(
            p['x'] - glow_radius, p['y'] - glow_radius,
            p['x'] + glow_radius, p['y'] + glow_radius,
            fill=glow_color, outline=""
        )

        for _ in range(8):
            angle = random.uniform(0, 2 * math.pi)
            distance = random.uniform(p['radius'] + 10, p['radius'] + 80)
            px = p['x'] + math.cos(angle) * distance
            py = p['y'] + math.sin(angle) * distance
            size = random.uniform(1, 2)
            particle_color = blend_with_bg("#ffffff", 0.6)
            self.canvas.create_oval(
                px - size, py - size,
                px + size, py + size,
                fill=particle_color, outline=""
            )

        tail_length = 70 if is_kyubi else 50
        tail_base_width = 22 if is_kyubi else 16

        for i in range(num_tails):
            base_angle = (i / num_tails) * 2 * math.pi - math.pi / 2
            sway = math.sin(now * 2.5 + i * 0.7) * 0.3
            angle = base_angle + sway

            outer_points = []
            inner_points = []

            num_segments = 20
            for j in range(num_segments):
                t = j / (num_segments - 1)
                dist = p['radius'] - 3 + tail_length * (t ** 0.6)
                wave1 = math.sin(t * math.pi * 2 + now * 3 + i * 0.5) * 0.12 * (1 - t)
                wave2 = math.cos(t * math.pi * 2.5 + now * 2.5 + i) * 0.06 * (1 - t)
                current_angle = angle + wave1 + wave2
                cx = p['x'] + math.cos(current_angle) * dist
                cy = p['y'] + math.sin(current_angle) * dist

                if t < 0.15:
                    width_factor = t / 0.15 * 0.6
                elif t > 0.8:
                    width_factor = (1 - t) / 0.2 * 0.6
                else:
                    width_factor = 0.6 + math.sin((t - 0.15) * math.pi / 0.65) * 0.2

                fluff = math.sin(t * 8 + now * 4 + i) * 0.05 * (1 - t)
                width_factor += fluff
                w = tail_base_width * width_factor
                perp_angle = current_angle + math.pi / 2

                outer_x = cx + math.cos(perp_angle) * w
                outer_y = cy + math.sin(perp_angle) * w
                inner_x = cx - math.cos(perp_angle) * w
                inner_y = cy - math.sin(perp_angle) * w

                outer_points.append((outer_x, outer_y))
                inner_points.append((inner_x, inner_y))

            all_points = []
            for pt in outer_points:
                all_points.extend([pt[0], pt[1]])

            if len(outer_points) > 0 and len(inner_points) > 0:
                last_outer = outer_points[-1]
                last_inner = inner_points[-1]
                tip_x = (last_outer[0] + last_inner[0]) / 2 + math.cos(angle) * 10
                tip_y = (last_outer[1] + last_inner[1]) / 2 + math.sin(angle) * 10
                all_points.extend([tip_x, tip_y])

            for pt in reversed(inner_points):
                all_points.extend([pt[0], pt[1]])

            if is_kyubi:
                fill_color = "#ff5722"
                outline_color = "#bf360c"
                tip_color = "#ffccbc"
            else:
                fill_color = "#ff9800"
                outline_color = "#e65100"
                tip_color = "#ffe0b2"

            if len(all_points) >= 6:
                self.canvas.create_polygon(
                    all_points,
                    fill=fill_color,
                    outline=outline_color,
                    width=2,
                    smooth=True
                )

            if len(outer_points) > 0:
                last_outer = outer_points[-1]
                last_inner = inner_points[-1]
                tip_center_x = (last_outer[0] + last_inner[0]) / 2
                tip_center_y = (last_outer[1] + last_inner[1]) / 2
                tip_radius = 5 if is_kyubi else 4
                self.canvas.create_oval(
                    tip_center_x - tip_radius, tip_center_y - tip_radius,
                    tip_center_x + tip_radius, tip_center_y + tip_radius,
                    fill=tip_color, outline=""
                )

    def update(self):
        if not self.running:
            return

        now = time.time()

        if self.no_cooldown:
            self.p1["dash_cd_until"] = 0
            self.p2["dash_cd_until"] = 0

        for effect in self.hulk_transform_effects[:]:
            effect["x"] += effect["dx"]
            effect["y"] += effect["dy"]
            effect["dx"] *= 0.95
            effect["dy"] *= 0.95
            effect["life"] -= 0.03
            if effect["life"] <= 0:
                self.hulk_transform_effects.remove(effect)

        for crack in self.hulk_cracks[:]:
            crack["life"] -= 0.025
            if crack["life"] <= 0:
                self.hulk_cracks.remove(crack)

        for particle in self.naruto_particles[:]:
            particle["x"] += particle["dx"]
            particle["y"] += particle["dy"]
            particle["dx"] *= 0.95
            particle["dy"] *= 0.95
            particle["rotation"] += particle["rot_speed"]
            particle["life"] -= 0.025
            if particle["life"] <= 0:
                self.naruto_particles.remove(particle)

        for piece in self.puzzle_pieces[:]:
            piece["x"] += piece["dx"]
            piece["y"] += piece["dy"]
            piece["dx"] *= 0.93
            piece["dy"] *= 0.93
            piece["rotation"] += piece["rot_speed"]
            piece["life"] -= 0.012
            if piece["life"] <= 0:
                self.puzzle_pieces.remove(piece)

        for particle in self.nagi_particles[:]:
            particle["x"] += particle["dx"]
            particle["y"] += particle["dy"]
            particle["dx"] *= 0.95
            particle["dy"] *= 0.95
            particle["life"] -= 0.02
            if particle["life"] <= 0:
                self.nagi_particles.remove(particle)

        for void in self.nagi_void_aura[:]:
            owner = None
            for p in [self.p1, self.p2]:
                if void["owner_id"] == id(p) and p["char_type"] == "Nagi":
                    owner = p
                    break
            if owner:
                void["angle"] += void["speed"]
                void["x"] = owner['x'] + math.cos(void["angle"]) * void["distance"]
                void["y"] = owner['y'] + math.sin(void["angle"]) * void["distance"]
            void["life"] -= 0.02
            if void["life"] <= 0:
                self.nagi_void_aura.remove(void)

        for s in self.skull_auras[:]:
            s["angle"] += s["speed"]
            s["x"] += math.cos(s["angle"]) * 0.5
            s["y"] += math.sin(s["angle"]) * 0.5
            s["life"] -= 0.03
            if s["life"] <= 0:
                self.skull_auras.remove(s)

        for petal in self.kaiser_petals[:]:
            petal["x"] += petal["dx"]
            petal["y"] += petal["dy"]
            petal["dx"] *= 0.99
            petal["dy"] *= 0.99
            petal["x"] += math.sin(petal["life"] * petal["sway_speed"]) * petal["sway_amount"]
            petal["y"] -= 0.3
            petal["rotation"] += petal["rot_speed"]
            petal["life"] -= 0.015
            if petal["life"] <= 0:
                self.kaiser_petals.remove(petal)

        if self.ai_mode:
            self.process_ai(self.p1, self.p2, "Blue")
            self.process_ai(self.p2, self.p1, "Red")
        else:
            self.move_player(self.p1, 'w', 's', 'a', 'd')
            self.move_player(self.p2, 'up', 'down', 'left', 'right')

        self.move_gk()

        for p in [self.p1, self.p2]:
            if p["target_text"] != "":
                if len(p["dialogue"]) < len(p["target_text"]):
                    if now - p["last_char_t"] > 0.04:
                        p["dialogue"] += p["target_text"][len(p["dialogue"])]
                        p["last_char_t"] = now
                elif now - p["last_char_t"] > 3.0:
                    p["target_text"] = p["dialogue"] = ""

        if now > self.rin_ability_until:
            self.gy1_blue = self.gy1_red = self.sh // 2 - self.gh_base // 2
            self.gy2_blue = self.gy2_red = self.sh // 2 + self.gh_base // 2
            self.rin_ability_user = None

        b = self.ball
        is_time_stopped = (now < self.time_stop_until)

        target_ts_factor = 1.0 if is_time_stopped else 0.0
        self.ts_factor += (target_ts_factor - self.ts_factor) * 0.1

        active_knives = []
        for k in self.knives:
            if not k.get('frozen', False):
                k['x'] += k['dx']
                k['y'] += k['dy']
            opp = self.p2 if k["owner"] == self.p1 else self.p1
            if math.hypot(k['x'] - opp['x'], k['y'] - opp['y']) < opp['radius']:
                opp['stunned_until'] = now + 1.5
                continue
            if 0 < k['x'] < self.sw and 0 < k['y'] < self.sh:
                active_knives.append(k)
        self.knives = active_knives

        if self.impact_effect:
            self.impact_effect['r'] += 15
            self.impact_effect['alpha'] -= 0.1
            if self.impact_effect['alpha'] <= 0:
                self.impact_effect = None

        goal_scored = False

        if b['dribbler'] is None:
            speed = math.hypot(b['dx'], b['dy'])
            if speed > 0.5:
                b['rotation'] += speed * 0.05
        else:
            p = b['dribbler']
            is_moving = False
            if p == self.p1:
                if 'w' in self.keys or 's' in self.keys:
                    is_moving = True
            else:
                if 'Up' in self.keys or 'Down' in self.keys:
                    is_moving = True
            if is_moving:
                speed = p['base_speed'] * (0.7 if p['dribbling'] else 1.0)
                b['rotation'] += speed * 0.03

        if now > self.freeze_until:
            for p in [self.p1, self.p2]:
                if is_time_stopped and p != self.ts_owner: continue
                opp = self.p2 if p == self.p1 else self.p1
                if opp.get('is_dashing', False) or (now < p["stunned_until"] and not p.get('is_dashing')): continue

                if math.hypot(p['x'] - b['x'], p['y'] - b['y']) < p['radius'] + b['radius'] + 12:
                    if b['dribbler'] == opp and now - b['steal_t'] > 0.5:
                        if opp["char_type"] == "Naruto" and now < opp.get("naruto_aura_until", 0) and opp.get(
                                "naruto_counter_ready", False):
                            self.play_game_sound("tackle")
                            angle_to_opp = math.atan2(p['y'] - opp['y'], p['x'] - opp['x'])
                            p['x'] += math.cos(angle_to_opp) * 120
                            p['y'] += math.sin(angle_to_opp) * 120
                            p['stunned_until'] = now + 1.0
                            p['dribbling'] = False
                            opp["naruto_kyubi_until"] = now + 3.0
                            opp["naruto_counter_ready"] = False
                            opp["naruto_aura_until"] = now + 3.0
                            opp['target_text'] = random.choice(NARUTO_QUOTES)
                            opp['dialogue'] = ""
                            opp['last_char_t'] = now
                            self.spawn_naruto_particles(opp['x'], opp['y'], "#ff6600")
                            continue

                        if opp["char_type"] == "Isagi" and now < opp['boost_until']:
                            self.play_game_sound("puzzle")
                            self.spawn_puzzle_pieces(opp['x'], opp['y'])
                            self.deactivate_isagi_ability(opp)
                        self.play_game_sound("tackle")
                        opp['dribbling'] = False
                        b['dribbler'] = p
                        b['steal_t'] = now
                        p['dribbling'] = True
                        b['curve'] = 0
                        b['rin_kicker'] = None
                        if p["char_type"] == "Pudge": opp["stunned_until"] = now + 0.7

                    elif b['dribbler'] is None and now - b['kick_t'] > 0.2:
                        b['dribbler'] = p
                        b['steal_t'] = now
                        p['dribbling'] = True
                        b['curve'] = 0
                        b['rin_kicker'] = None
                        if p["char_type"] == "Isagi" and now < p['boost_until']:
                            self.play_game_sound("puzzle")
                            self.spawn_puzzle_pieces(p['x'], p['y'])
                            self.deactivate_isagi_ability(p)

            ball_frozen = is_time_stopped and (b['dribbler'] != self.ts_owner)

            if not ball_frozen:
                if self.hook["active"]:
                    h = self.hook
                    opp = self.p2 if h["owner"] == self.p1 else self.p1
                    if h["target"] is None:
                        h["x"] += h["dx"]
                        h["y"] += h["dy"]
                        h["dist"] += 1
                        if math.hypot(h["x"] - b["x"], h["y"] - b["y"]) < 45:
                            h["target"] = "ball"
                            # Попадание по мячу - сразу hook2
                            self.stop_game_sound("hook")
                            self.play_game_sound("hook2")
                        elif math.hypot(h["x"] - opp["x"], h["y"] - opp["y"]) < opp["radius"] + 20:
                            h["target"] = "opp"
                            # Попадание по противнику - сразу hook2
                            self.stop_game_sound("hook")
                            self.play_game_sound("hook2")
                        elif h["dist"] > 25:
                            h["target"] = "none"
                    else:
                        # Возврат хука
                        angle = math.atan2(h["owner"]["y"] - h["y"], h["owner"]["x"] - h["x"])
                        h["x"] += math.cos(angle) * 40
                        h["y"] += math.sin(angle) * 40
                        if h["target"] == "ball":
                            b["x"], b["y"] = h["x"], h["y"]
                            b["dribbler"] = None
                            b['curve'] = 0
                            b['rin_kicker'] = None
                        elif h["target"] == "opp":
                            if b["dribbler"] == opp: b["dribbler"] = None
                            opp["x"], opp["y"] = h["x"], h["y"]
                            b['curve'] = 0
                            b['rin_kicker'] = None
                        # Когда хук вернулся к Пуджу
                        if math.hypot(h["x"] - h["owner"]["x"], h["y"] - h["owner"]["y"]) < 50:
                            if h["target"] == "opp": opp["stunned_until"] = now + 1.2
                            h["active"] = False

                for gk, tm in [(self.gk_blue, self.p1), (self.gk_red, self.p2)]:
                    if math.hypot(gk['x'] - b['x'], gk['y'] - b['y']) < gk['radius'] + b['radius']:
                        ang = math.atan2(tm['y'] - gk['y'], tm['x'] - gk['x'])
                        b['dx'] = math.cos(ang) * 35
                        b['dy'] = math.sin(ang) * 35
                        b['dribbler'] = None
                        b['kick_t'] = now
                        b['curve'] = 0
                        b['rin_kicker'] = None
                        self.play_game_sound("tackle")

                if b['dribbler']:
                    p = b['dribbler']
                    self.last_scorer = p
                    if not p.get('is_dashing'):
                        b['x'] = p['x'] + math.cos(p['angle']) * (p['radius'] + b['radius'] + 2)
                        b['y'] = p['y'] + math.sin(p['angle']) * (p['radius'] + b['radius'] + 2)
                else:
                    if abs(b['curve']) > 0.01:
                        spd = math.hypot(b['dx'], b['dy'])
                        if spd > 0.1:
                            current_ang = math.atan2(b['dy'], b['dx'])
                            curve_effect = b['curve'] * 0.03
                            new_ang = current_ang + curve_effect
                            b['dx'] = math.cos(new_ang) * spd
                            b['dy'] = math.sin(new_ang) * spd
                        b['curve'] *= 0.98

                    b['x'] += b['dx']
                    b['y'] += b['dy']
                    b['dx'] *= 0.97
                    b['dy'] *= 0.97

                    if self.gy1_blue < b['y'] < self.gy2_blue and b['x'] <= b['radius']:
                        if now < self.shield_blue_until:
                            b['x'] = b['radius'] + 20
                            b['dx'] = abs(b['dx']) * 1.5
                            b['dy'] = b['dy'] * 0.5
                            b['curve'] = 0
                            b['rin_kicker'] = None
                            self.play_game_sound("tackle")
                        else:
                            self.score[1] += 1
                            self.last_scorer = b.get('rin_kicker') or self.last_scorer
                            goal_scored = True

                    elif self.gy1_red < b['y'] < self.gy2_red and b['x'] >= self.sw - b['radius']:
                        if now < self.shield_red_until:
                            b['x'] = self.sw - b['radius'] - 20
                            b['dx'] = -abs(b['dx']) * 1.5
                            b['dy'] = b['dy'] * 0.5
                            b['curve'] = 0
                            b['rin_kicker'] = None
                            self.play_game_sound("tackle")
                        else:
                            self.score[0] += 1
                            self.last_scorer = b.get('rin_kicker') or self.last_scorer
                            goal_scored = True

                    if not goal_scored:
                        if b['x'] < b['radius']:
                            b['x'] = b['radius']
                            b['dx'] = abs(b['dx'])
                            b['curve'] = 0
                            b['rin_kicker'] = None
                        elif b['x'] > self.sw - b['radius']:
                            b['x'] = self.sw - b['radius']
                            b['dx'] = -abs(b['dx'])
                            b['curve'] = 0
                            b['rin_kicker'] = None
                        if b['y'] < b['radius']:
                            b['y'] = b['radius']
                            b['dy'] = abs(b['dy'])
                            b['curve'] = 0
                            b['rin_kicker'] = None
                        elif b['y'] > self.sh - b['radius']:
                            b['y'] = self.sh - b['radius']
                            b['dy'] = -abs(b['dy'])
                            b['curve'] = 0
                            b['rin_kicker'] = None

            if b['x'] < -200 or b['x'] > self.sw + 200 or b['y'] < -200 or b['y'] > self.sh + 200:
                b['x'], b['y'] = self.sw // 2, self.sh // 2
                b['dx'] = b['dy'] = 0
                b['dribbler'] = None
                b['curve'] = 0
                b['rin_kicker'] = None

        if goal_scored:
            self.trigger_goal()

        self.draw()
        if self.running:
            self.root.after(16, self.update)

    def trigger_goal(self):
        self.play_game_sound("goal")

        self.goal_text_id = "GOAL!"
        self.knives = []
        self.time_stop_until = 0
        self.ball['curve'] = 0
        self.ball['rin_kicker'] = None

        if self.last_scorer:
            if self.last_scorer["char_type"] == "Nagi":
                is_ult_goal = (self.last_scorer["target_text"] == "Лучший в мире.")
                if is_ult_goal:
                    self.last_scorer["last_char_t"] = time.time()
                else:
                    self.last_scorer["nagi_charge"] = min(1.0, self.last_scorer["nagi_charge"] + 0.5)
                    self.last_scorer["target_text"] = random.choice(NAGI_QUOTES)
                    self.last_scorer["dialogue"] = ""
                    self.last_scorer["last_char_t"] = time.time()
            elif self.last_scorer["char_type"] == "Dio":
                self.last_scorer["target_text"] = random.choice(DIO_QUOTES)
                self.last_scorer["dialogue"] = ""
                self.last_scorer["last_char_t"] = time.time()
            elif self.last_scorer["char_type"] == "Naruto":
                self.last_scorer["target_text"] = random.choice(NARUTO_QUOTES)
                self.last_scorer["dialogue"] = ""
                self.last_scorer["last_char_t"] = time.time()

        self.freeze_until = time.time() + 1.5

        total_goals = self.score[0] + self.score[1]
        if self.ai_mode and self.switch_goals > 0 and total_goals % self.switch_goals == 0:
            self.root.after(1200, self.switch_ai_chars)
        else:
            self.root.after(1200, self.reset_game)

    def switch_ai_chars(self):
        old_chars = [self.p1["char_type"], self.p2["char_type"]]
        available = [c for c in CHARACTER_TYPES.keys() if c not in old_chars]
        new_c1, new_c2 = random.sample(available, 2)
        score_copy = self.score.copy()
        self.p1 = self.create_player(self.p1['start_x'], self.p1['start_y'], self.p1['color'], new_c1, "Blue")
        self.p2 = self.create_player(self.p2['start_x'], self.p2['start_y'], self.p2['color'], new_c2, "Red")
        self.score = score_copy
        self.goal_text_id = "СМЕНА ГЕРОЕВ!"
        self.root.after(1500, self.reset_game)

    def reset_game(self):
        self.goal_text_id = self.active_warning = self.last_scorer = self.impact_effect = None
        self.rin_ability_until = self.isagi_dim_until = self.shield_blue_until = self.shield_red_until = self.time_stop_until = 0
        self.rin_ability_user = None
        self.knives = []
        self.ts_owner = None
        self.ts_factor = 0.0
        self.puzzle_pieces = []
        self.naruto_particles = []
        self.nagi_particles = []
        self.nagi_void_aura = []
        self.skull_auras = []
        self.hulk_cracks = []
        self.hulk_transform_effects = []
        self.kaiser_petals = []
        for p in [self.p1, self.p2]:
            p['x'], p['y'] = p['start_x'], p['start_y']
            p['angle'] = 0 if p['side'] == "Blue" else math.pi
            p['boost_until'] = p['stunned_until'] = p['snake_until'] = p['rot_until'] = 0
            p['dribbling'] = False
            p["radius"] = CHARACTER_TYPES[p["char_type"]]["base_radius"]
            p["flies"] = []
            p["skull_active"] = False
            p["skull_start_t"] = 0
            p["nagi_hitbox_until"] = 0
            p["naruto_aura_until"] = 0
            p["naruto_kyubi_until"] = 0
            p["naruto_counter_ready"] = False
            p["hulk_scale"] = 1.0
            p["hulk_original_radius"] = CHARACTER_TYPES[p["char_type"]]["base_radius"]
            p["kaiser_aura_until"] = 0
        self.ball.update(
            {"x": self.sw // 2, "y": self.sh // 2, "dx": 0, "dy": 0, "dribbler": None, "curve": 0, "rin_kicker": None,
             "rotation": 0})

    def simulate_rin_curve(self, start_x, start_y, start_angle, power):
        pts = [(start_x, start_y)]
        sim_x, sim_y = start_x, start_y
        sim_dx = math.cos(start_angle) * power
        sim_dy = math.sin(start_angle) * power
        curve = -1.5
        for _ in range(15):
            spd = math.hypot(sim_dx, sim_dy)
            if spd < 0.3:
                break
            if abs(curve) > 0.01:
                current_ang = math.atan2(sim_dy, sim_dx)
                curve_effect = curve * 0.03
                new_ang = current_ang + curve_effect
                sim_dx = math.cos(new_ang) * spd
                sim_dy = math.sin(new_ang) * spd
            curve *= 0.98
            sim_x += sim_dx
            sim_y += sim_dy
            sim_dx *= 0.97
            sim_dy *= 0.97
            if sim_x < self.ball['radius']:
                sim_x = self.ball['radius']
                sim_dx *= -1
                curve = 0
            elif sim_x > self.sw - self.ball['radius']:
                sim_x = self.sw - self.ball['radius']
                sim_dx *= -1
                curve = 0
            if sim_y < self.ball['radius']:
                sim_y = self.ball['radius']
                sim_dy *= -1
                curve = 0
            elif sim_y > self.sh - self.ball['radius']:
                sim_y = self.sh - self.ball['radius']
                sim_dy *= -1
                curve = 0
            pts.append((sim_x, sim_y))
            if (self.gy1_blue < sim_y < self.gy2_blue and sim_x < 0) or \
                    (self.gy1_red < sim_y < self.gy2_red and sim_x > self.sw):
                break
            if sim_x < -50 or sim_x > self.sw + 50 or sim_y < -50 or sim_y > self.sh + 50:
                break
        return pts

    def draw(self):
        self.canvas.delete("all")
        now = time.time()

        bg_col = interpolate_color("#007539", "#2a0033", self.ts_factor)
        line_col = interpolate_color("#ffffff", "#000000", self.ts_factor)
        text_col = interpolate_color("#ffffff", "#ffd700", self.ts_factor)

        self.canvas.configure(bg=bg_col)

        stripe_width = 80
        dark_stripe_color = interpolate_color("#006b33", "#24002e", self.ts_factor)
        light_stripe_color = interpolate_color("#007d3d", "#2c0038", self.ts_factor)

        for i in range(0, self.sw + stripe_width, stripe_width):
            if (i // stripe_width) % 2 == 0:
                color = light_stripe_color
            else:
                color = dark_stripe_color
            self.canvas.create_rectangle(i, 0, i + stripe_width, self.sh, fill=color, outline="")

        self.canvas.create_line(self.sw // 2, 0, self.sw // 2, self.sh, fill=line_col, width=3)
        self.canvas.create_oval(self.sw // 2 - 100, self.sh // 2 - 100, self.sw // 2 + 100, self.sh // 2 + 100,
                                outline=line_col, width=3)

        penalty_area_width = 300
        penalty_area_height = 600
        self.canvas.create_rectangle(0, self.sh // 2 - penalty_area_height // 2,
                                     penalty_area_width, self.sh // 2 + penalty_area_height // 2,
                                     outline=line_col, width=2)
        self.canvas.create_rectangle(self.sw - penalty_area_width, self.sh // 2 - penalty_area_height // 2,
                                     self.sw, self.sh // 2 + penalty_area_height // 2,
                                     outline=line_col, width=2)

        goal_area_width = 120
        goal_area_height = 300
        self.canvas.create_rectangle(0, self.sh // 2 - goal_area_height // 2,
                                     goal_area_width, self.sh // 2 + goal_area_height // 2,
                                     outline=line_col, width=2)
        self.canvas.create_rectangle(self.sw - goal_area_width, self.sh // 2 - goal_area_height // 2,
                                     self.sw, self.sh // 2 + goal_area_height // 2,
                                     outline=line_col, width=2)

        self.canvas.create_rectangle(0, self.gy1_blue, self.gw, self.gy2_blue, fill="#1e88e5", outline=line_col,
                                     width=2)
        self.canvas.create_rectangle(self.sw - self.gw, self.gy1_red, self.sw, self.gy2_red, fill="#e53935",
                                     outline=line_col, width=2)

        self.canvas.create_oval(180 - 3, self.sh // 2 - 3, 180 + 3, self.sh // 2 + 3, fill=line_col)
        self.canvas.create_oval(self.sw - 180 - 3, self.sh // 2 - 3, self.sw - 180 + 3, self.sh // 2 + 3, fill=line_col)

        if self.no_cooldown:
            self.canvas.create_text(self.sw - 15, 25, text="БЕЗ КД", fill="#ff0000",
                                    font=("Arial", 16, "bold"), anchor="ne")

        if self.active_warning and now < self.active_warning["until"]:
            p = self.active_warning["player"]
            off = self.active_warning.get("offset", 35)
            self.canvas.create_text(p['x'], p['y'] - p['radius'] - off, text=self.active_warning["text"],
                                    fill="#ff3333", font=("Arial", 22, "bold"))

        if (now < self.isagi_dim_until or self.p1['snake_until'] > now or self.p2[
            'snake_until'] > now) and self.ts_factor < 0.5:
            self.canvas.create_rectangle(0, 0, self.sw, self.sh, fill="#001a1a", stipple="gray50")

        if now < self.shield_blue_until:
            self.canvas.create_rectangle(0, self.gy1_blue, self.gw, self.gy2_blue, outline="#00ffff", width=8)
        if now < self.shield_red_until:
            self.canvas.create_rectangle(self.sw - self.gw, self.gy1_red, self.sw, self.gy2_red, outline="#00ffff",
                                         width=8)

        for k in self.knives:
            kl = 20
            x2 = k['x'] - math.cos(k['angle']) * kl
            y2 = k['y'] - math.sin(k['angle']) * kl
            self.canvas.create_line(k['x'], k['y'], x2, y2, fill="gold", width=4)
            self.canvas.create_polygon(k['x'], k['y'], x2, y2, k['x'] - 5, k['y'] - 5, fill="yellow")

        if self.impact_effect:
            r = self.impact_effect['r']
            self.canvas.create_oval(self.impact_effect['x'] - r, self.impact_effect['y'] - r,
                                    self.impact_effect['x'] + r, self.impact_effect['y'] + r,
                                    outline="yellow", width=4)

        if self.hook["active"]:
            self.canvas.create_line(self.hook["owner"]["x"], self.hook["owner"]["y"], self.hook["x"], self.hook["y"],
                                    fill="#5d4037", width=8)
            self.canvas.create_oval(self.hook["x"] - 10, self.hook["y"] - 10, self.hook["x"] + 10, self.hook["y"] + 10,
                                    fill="silver", outline="black")

        for effect in self.hulk_transform_effects:
            alpha = effect["life"]
            if alpha > 0:
                size = 4 * alpha
                self.canvas.create_oval(
                    effect["x"] - size, effect["y"] - size,
                    effect["x"] + size, effect["y"] + size,
                    fill=effect["color"], outline=""
                )

        for crack in self.hulk_cracks:
            if crack["life"] > 0:
                alpha = crack["life"]
                start_x, start_y = crack["x"], crack["y"]
                prev_x, prev_y = start_x, start_y
                for i in range(1, crack["segments"] + 1):
                    progress = i / crack["segments"]
                    offset_angle = math.sin(progress * math.pi * 2.5 + crack["angle"]) * 0.8
                    current_angle = crack["angle"] + offset_angle
                    x = start_x + math.cos(current_angle) * crack["length"] * progress
                    y = start_y + math.sin(current_angle) * crack["length"] * progress
                    self.canvas.create_line(prev_x, prev_y, x, y,
                                            fill="#0d2d0d", width=5 * alpha)
                    self.canvas.create_line(prev_x, prev_y, x, y,
                                            fill="#2d5d2d", width=2 * alpha)
                    if i % random.randint(2, 4) == 0 and i < crack["segments"] - 1:
                        branch_angle = current_angle + random.uniform(-1.2, 1.2)
                        branch_length = crack["length"] * random.uniform(0.1, 0.35)
                        bx = x + math.cos(branch_angle) * branch_length
                        by = y + math.sin(branch_angle) * branch_length
                        self.canvas.create_line(x, y, bx, by,
                                                fill="#1a4a1a", width=2 * alpha)
                    prev_x, prev_y = x, y
                if alpha > 0.5:
                    for _ in range(3):
                        particle_angle = crack["angle"] + random.uniform(-0.5, 0.5)
                        particle_dist = crack["length"] * random.uniform(0.1, 0.9)
                        px = start_x + math.cos(particle_angle) * particle_dist
                        py = start_y + math.sin(particle_angle) * particle_dist
                        size = random.uniform(1, 3)
                        self.canvas.create_oval(px - size, py - size, px + size, py + size,
                                                fill="#1a3d1a", outline="")

        for particle in self.naruto_particles:
            alpha = particle["life"] / particle["max_life"]
            if alpha > 0:
                color = particle["color"]
                size = particle["size"] * alpha
                self.canvas.create_oval(
                    particle["x"] - size, particle["y"] - size * 0.5,
                    particle["x"] + size, particle["y"] + size * 0.5,
                    fill=color, outline=""
                )

        for piece in self.puzzle_pieces:
            if piece["life"] > 0.1:
                self.draw_puzzle_piece(piece["x"], piece["y"], piece["size"], piece["rotation"], piece["color"],
                                       piece["tabs"])

        for s in self.skull_auras:
            if s["life"] > 0:
                alpha = s["life"] / s["max_life"]
                sz = s["size"] * alpha
                self.canvas.create_oval(s["x"] - sz, s["y"] - sz, s["x"] + sz, s["y"] + sz,
                                        fill=s["color"], outline="")

        for void in self.nagi_void_aura:
            if void["life"] > 0:
                alpha = void["life"] / void["max_life"]
                sz = void["size"] * alpha
                self.canvas.create_oval(void["x"] - sz, void["y"] - sz, void["x"] + sz, void["y"] + sz,
                                        fill=void["color"], outline="")

        for particle in self.nagi_particles:
            if particle["life"] > 0:
                alpha = particle["life"] / particle["max_life"]
                size = particle["size"] * alpha
                self.canvas.create_oval(
                    particle["x"] - size, particle["y"] - size,
                    particle["x"] + size, particle["y"] + size,
                    fill=particle["color"], outline="#666666", width=1
                )

        self.canvas.create_oval(self.gk_blue['x'] - self.gk_blue['radius'], self.gk_blue['y'] - self.gk_blue['radius'],
                                self.gk_blue['x'] + self.gk_blue['radius'], self.gk_blue['y'] + self.gk_blue['radius'],
                                fill="#4fc3f7", outline="white", width=2)
        self.canvas.create_oval(self.gk_red['x'] - self.gk_red['radius'], self.gk_red['y'] - self.gk_red['radius'],
                                self.gk_red['x'] + self.gk_red['radius'], self.gk_red['y'] + self.gk_red['radius'],
                                fill="#ff8a65", outline="white", width=2)
        self.canvas.create_text(self.sw // 2, 60, text=f"{self.score[0]} : {self.score[1]}", fill=text_col,
                                font=("Arial", 60, "bold"))

        for p in [self.p1, self.p2]:
            if p["char_type"] == "Naruto" and (
                    now < p.get("naruto_aura_until", 0) or now < p.get("naruto_kyubi_until", 0)):
                self.draw_naruto_aura(p, now)

            if p["char_type"] == "Kaiser" and now < p.get('kaiser_aura_until', 0):
                aura_progress = (p['kaiser_aura_until'] - now) / 4.0

                outer_layers = [
                    (p['radius'] + 65, "#ab47bc", 0.15),
                    (p['radius'] + 55, "#7e57c2", 0.25),
                    (p['radius'] + 45, "#5c6bc0", 0.35),
                    (p['radius'] + 35, "#42a5f5", 0.45),
                    (p['radius'] + 25, "#2196f3", 0.55),
                ]

                inner_layers = [
                    (p['radius'] + 15, "#1976d2", 0.65),
                    (p['radius'] + 8, "#1565c0", 0.75),
                    (p['radius'] + 3, "#0d47a1", 0.85),
                ]

                for radius, color, opacity in outer_layers:
                    bg_rgb = hex_to_rgb("#007539")
                    aura_rgb = hex_to_rgb(color)
                    blended = tuple(int(aura_rgb[i] * opacity + bg_rgb[i] * (1 - opacity)) for i in range(3))
                    final_color = rgb_to_hex(blended)

                    self.canvas.create_oval(
                        p['x'] - radius, p['y'] - radius,
                        p['x'] + radius, p['y'] + radius,
                        fill=final_color, outline=""
                    )

                for radius, color, opacity in inner_layers:
                    bg_rgb = hex_to_rgb("#007539")
                    aura_rgb = hex_to_rgb(color)
                    blended = tuple(int(aura_rgb[i] * opacity + bg_rgb[i] * (1 - opacity)) for i in range(3))
                    final_color = rgb_to_hex(blended)

                    self.canvas.create_oval(
                        p['x'] - radius, p['y'] - radius,
                        p['x'] + radius, p['y'] + radius,
                        fill=final_color, outline=""
                    )

                for i in range(8):
                    line_angle = (i / 8) * 2 * math.pi + now * 1.2

                    inner_point = 0
                    outer_point = p['radius'] + 60

                    x1 = p['x'] + math.cos(line_angle) * inner_point
                    y1 = p['y'] + math.sin(line_angle) * inner_point
                    x2 = p['x'] + math.cos(line_angle) * outer_point
                    y2 = p['y'] + math.sin(line_angle) * outer_point

                    line_progress = (math.sin(now * 3 + i * 0.8) + 1) / 2
                    if line_progress < 0.5:
                        t = line_progress * 2
                        line_color = interpolate_color("#42a5f5", "#7e57c2", t)
                    else:
                        t = (line_progress - 0.5) * 2
                        line_color = interpolate_color("#7e57c2", "#ab47bc", t)

                    self.canvas.create_line(x1, y1, x2, y2, fill=line_color, width=3)

                    dot_size = 3
                    self.canvas.create_oval(
                        x2 - dot_size, y2 - dot_size,
                        x2 + dot_size, y2 + dot_size,
                        fill=line_color, outline=""
                    )

                core_radius = p['radius'] + 5
                self.canvas.create_oval(
                    p['x'] - core_radius, p['y'] - core_radius,
                    p['x'] + core_radius, p['y'] + core_radius,
                    fill="#42a5f5", outline="", stipple="gray25"
                )

                if aura_progress > 0.8 and random.random() < 0.1:
                    self.spawn_kaiser_petals(p, 3)

                if 0.4 < aura_progress < 0.6 and random.random() < 0.08:
                    self.spawn_kaiser_petals(p, 4)

                if now < p.get('stunned_until', 0):
                    if random.random() < 0.15:
                        self.spawn_kaiser_petals(p, 2)

            if p["char_type"] == "Pudge" and now < p.get("rot_until", 0):
                self.canvas.create_oval(p['x'] - 140, p['y'] - 140,
                                        p['x'] + 140, p['y'] + 140,
                                        fill="#0d3d0d", outline="#1a6b1a",
                                        stipple="gray25", width=2)
                self.canvas.create_oval(p['x'] - 100, p['y'] - 100,
                                        p['x'] + 100, p['y'] + 100,
                                        fill="", outline="#2d8d2d",
                                        stipple="gray25", width=2)
                for fly in p.get("flies", []):
                    fly_angle = fly["angle"] + now * fly["speed"]
                    fly_dist = fly["dist"] + math.sin(now * 3 + fly["wobble_offset"]) * 20
                    fx = p['x'] + math.cos(fly_angle) * fly_dist
                    fy = p['y'] + math.sin(fly_angle) * fly_dist + math.sin(now * 5 + fly["wobble_offset"]) * 15
                    size = fly["size"]
                    self.canvas.create_oval(fx - size, fy - size, fx + size, fy + size,
                                            fill="#1a1a1a", outline="#333333", width=1)
                    wing_flap = math.sin(now * 15 + fly["wobble_offset"]) * 3
                    self.canvas.create_line(fx - size, fy - size, fx - size * 2, fy - size * 2 + wing_flap,
                                            fill="#555555", width=1)
                    self.canvas.create_line(fx + size, fy - size, fx + size * 2, fy - size * 2 + wing_flap,
                                            fill="#555555", width=1)

            if p["char_type"] == "Nagi" and now < p.get("nagi_hitbox_until", 0):
                self.canvas.create_oval(p['x'] - 200, p['y'] - 200,
                                        p['x'] + 200, p['y'] + 200,
                                        fill="", outline="#ffffff", width=2, dash=(5, 5))

        for p in [self.p1, self.p2]:
            if p.get("skull_active", False) and p["char_type"] == "Nagi":
                aura_radius = p['radius'] + 15
                self.canvas.create_oval(
                    p['x'] - aura_radius - 8, p['y'] - aura_radius - 8,
                    p['x'] + aura_radius + 8, p['y'] + aura_radius + 8,
                    fill="#1a0033", outline="", stipple="gray50"
                )
                self.canvas.create_oval(
                    p['x'] - aura_radius - 3, p['y'] - aura_radius - 3,
                    p['x'] + aura_radius + 3, p['y'] + aura_radius + 3,
                    fill="#2d004d", outline="", stipple="gray25"
                )

                if random.random() < 0.3:
                    self.spawn_nagi_particles(p, 2)
                if random.random() < 0.25:
                    self.spawn_nagi_void_aura(p, 3)

                skull_x = p['x'] - p['radius'] - 40
                skull_y = p['y'] - p['radius'] - 30

                if random.random() < 0.4:
                    self.spawn_skull_aura(skull_x, skull_y, 3)

                self.draw_skull(skull_x, skull_y, 1.0, now)

            if p["char_type"] == "Aiku" and now < p['snake_until']:
                # Змея выходит из Айку - компактная, одинаковой толщины
                num_segments = 45
                snake_length = 160
                start_radius = p['radius'] + 3
                end_radius = start_radius + snake_length
                constant_thickness = 32

                snake_points = []
                for i in range(num_segments):
                    t = i / (num_segments - 1)

                    wave1 = math.sin(t * 5 + now * 3.5) * 8 * t
                    wave2 = math.cos(t * 4 + now * 2.8) * 6 * t

                    spiral_angle = t * 5.0 * math.pi + now * 4.5
                    radius = start_radius + t * snake_length

                    sx = p['x'] + math.cos(spiral_angle + wave1 * 0.02) * radius
                    sy = p['y'] + math.sin(spiral_angle + wave2 * 0.02) * radius

                    snake_points.append((sx, sy, constant_thickness, t))

                # Внешний контур
                for i in range(len(snake_points) - 1):
                    x1, y1, t1, _ = snake_points[i]
                    x2, y2, t2, _ = snake_points[i + 1]

                    self.canvas.create_line(x1, y1, x2, y2,
                                            fill="#4a0000",
                                            width=constant_thickness + 4,
                                            capstyle="round",
                                            joinstyle="round")

                # Основное тело + блик + полоски
                for i in range(len(snake_points) - 1):
                    x1, y1, t1, progress = snake_points[i]
                    x2, y2, t2, _ = snake_points[i + 1]

                    if progress < 0.2:
                        body_color = "#b71c1c"
                    elif progress < 0.5:
                        body_color = "#d32f2f"
                    else:
                        body_color = "#e53935"

                    self.canvas.create_line(x1, y1, x2, y2,
                                            fill=body_color,
                                            width=constant_thickness,
                                            capstyle="round",
                                            joinstyle="round")

                    if i < len(snake_points) - 2:
                        nx, ny, _, _ = snake_points[i + 2]
                        body_ang = math.atan2(ny - y1, nx - x2)
                    else:
                        body_ang = math.atan2(y2 - y1, x2 - x1)

                    perp_angle = body_ang + math.pi / 2
                    h_dist = constant_thickness * 0.15

                    self.canvas.create_line(
                        x1 + math.cos(perp_angle) * h_dist,
                        y1 + math.sin(perp_angle) * h_dist,
                        x2 + math.cos(perp_angle) * h_dist,
                        y2 + math.sin(perp_angle) * h_dist,
                        fill="#ff8a80",
                        width=constant_thickness * 0.2,
                        capstyle="round"
                    )

                # Ромбовидные полоски внутри
                for i in range(2, len(snake_points) - 2, 4):
                    x, y, thickness, progress = snake_points[i]

                    if progress < 0.1:
                        continue

                    if i > 0 and i < len(snake_points) - 1:
                        prev_x, prev_y, _, _ = snake_points[i - 1]
                        next_x, next_y, _, _ = snake_points[i + 1]
                        body_angle = math.atan2(next_y - prev_y, next_x - prev_x)
                    else:
                        continue

                    perp_angle = body_angle + math.pi / 2

                    half_width = constant_thickness * 0.85
                    half_length = constant_thickness * 0.3

                    stripe_type = i % 8
                    stripe_color = "#0a0a0a" if stripe_type < 4 else "#1a0a0a"
                    dot_color = "#444444" if stripe_type < 4 else "#333333"

                    diamond_points = [
                        x + math.cos(perp_angle) * half_width,
                        y + math.sin(perp_angle) * half_width,
                        x + math.cos(body_angle) * half_length,
                        y + math.sin(body_angle) * half_length,
                        x - math.cos(perp_angle) * half_width,
                        y - math.sin(perp_angle) * half_width,
                        x - math.cos(body_angle) * half_length,
                        y - math.sin(body_angle) * half_length,
                    ]

                    self.canvas.create_polygon(diamond_points,
                                               fill=stripe_color,
                                               outline="#2a2a2a",
                                               width=1,
                                               smooth=True)

                    for angle_offset in [math.pi / 2, -math.pi / 2]:
                        dot_x = x + math.cos(perp_angle + angle_offset) * half_width * 0.7
                        dot_y = y + math.sin(perp_angle + angle_offset) * half_width * 0.7
                        dot_size = 1.5
                        self.canvas.create_oval(dot_x - dot_size, dot_y - dot_size,
                                                dot_x + dot_size, dot_y + dot_size,
                                                fill=dot_color, outline="")

                # ГОЛОВА ЗМЕИ С РАСКРЫТОЙ ПАСТЬЮ (ИСПРАВЛЕНО)
                if len(snake_points) > 2:
                    head_x, head_y, head_t, head_progress = snake_points[-1]
                    prev_x, prev_y, _, _ = snake_points[-2]

                    head_angle = math.atan2(head_y - prev_y, head_x - prev_x)
                    head_size = constant_thickness * 1.2

                    # Угол раскрытия пасти (анимированный)
                    jaw_open = 0.45 + math.sin(now * 6) * 0.1

                    # Точка соединения челюстей (затылок)
                    joint_x = head_x + math.cos(head_angle + math.pi) * head_size * 0.35
                    joint_y = head_y + math.sin(head_angle + math.pi) * head_size * 0.35

                    # ВЕРХНЯЯ ЧЕЛЮСТЬ
                    upper_nose_x = head_x + math.cos(head_angle) * head_size * 1.2
                    upper_nose_y = head_y + math.sin(head_angle) * head_size * 1.2

                    upper_top_x = head_x + math.cos(head_angle + math.pi * 0.7) * head_size * 0.65
                    upper_top_y = head_y + math.sin(head_angle + math.pi * 0.7) * head_size * 0.65

                    upper_jaw_points = [
                        upper_nose_x, upper_nose_y,
                        upper_top_x, upper_top_y,
                        joint_x, joint_y,
                    ]

                    # НИЖНЯЯ ЧЕЛЮСТЬ (отклонена вниз на jaw_open)
                    lower_nose_x = head_x + math.cos(head_angle + jaw_open) * head_size * 0.95
                    lower_nose_y = head_y + math.sin(head_angle + jaw_open) * head_size * 0.95

                    lower_bottom_x = head_x + math.cos(head_angle - math.pi * 0.7 + jaw_open * 0.5) * head_size * 0.45
                    lower_bottom_y = head_y + math.sin(head_angle - math.pi * 0.7 + jaw_open * 0.5) * head_size * 0.45

                    lower_jaw_points = [
                        lower_nose_x, lower_nose_y,
                        lower_bottom_x, lower_bottom_y,
                        joint_x, joint_y,
                    ]

                    # ВНУТРЕННЯЯ ЧАСТЬ ПАСТИ
                    mouth_points = [
                        upper_nose_x, upper_nose_y,
                        joint_x, joint_y,
                        lower_nose_x, lower_nose_y,
                    ]

                    self.canvas.create_polygon(mouth_points,
                                               fill="#1a0000",
                                               outline="#3a0000",
                                               width=1.5,
                                               smooth=True)

                    # Верхняя челюсть
                    self.canvas.create_polygon(upper_jaw_points,
                                               fill="#c62828",
                                               outline="#6b0000",
                                               width=2,
                                               smooth=True)

                    # Нижняя челюсть
                    self.canvas.create_polygon(lower_jaw_points,
                                               fill="#a31515",
                                               outline="#5a0000",
                                               width=2,
                                               smooth=True)

                    # КЛЫКИ НА ВЕРХНЕЙ ЧЕЛЮСТИ
                    fang_length = head_size * 0.35
                    for fang_side in [-1, 1]:
                        fang_base_x = upper_nose_x + math.cos(head_angle + math.pi) * head_size * 0.35
                        fang_base_y = upper_nose_y + math.sin(head_angle + math.pi) * head_size * 0.35

                        fang_x = fang_base_x + math.cos(head_angle + math.pi / 2) * head_size * 0.15 * fang_side
                        fang_y = fang_base_y + math.sin(head_angle + math.pi / 2) * head_size * 0.15 * fang_side

                        tip_x = fang_x + math.cos(head_angle + jaw_open * 0.7) * fang_length
                        tip_y = fang_y + math.sin(head_angle + jaw_open * 0.7) * fang_length

                        fang_width = 2.5
                        fang_points = [
                            fang_x + math.cos(head_angle + math.pi / 2) * fang_width,
                            fang_y + math.sin(head_angle + math.pi / 2) * fang_width,
                            tip_x,
                            tip_y,
                            fang_x - math.cos(head_angle + math.pi / 2) * fang_width,
                            fang_y - math.sin(head_angle + math.pi / 2) * fang_width,
                        ]

                        self.canvas.create_polygon(fang_points,
                                                   fill="#f5f5f5",
                                                   outline="#9e9e9e",
                                                   width=1,
                                                   smooth=True)

                    # ГЛАЗА
                    eye_dist = head_size * 0.35
                    for eye_side in [-1, 1]:
                        ex = head_x + math.cos(head_angle + math.pi * 0.5 * eye_side) * eye_dist
                        ey = head_y + math.sin(head_angle + math.pi * 0.5 * eye_side) * eye_dist

                        eye_size = max(2.5, head_size * 0.18)

                        self.canvas.create_oval(ex - eye_size, ey - eye_size * 0.7,
                                                ex + eye_size, ey + eye_size * 0.7,
                                                fill="#ffeb3b", outline="#f57f17", width=1.5)

                        self.canvas.create_oval(ex - eye_size * 0.2, ey - eye_size * 0.65,
                                                ex + eye_size * 0.2, ey + eye_size * 0.65,
                                                fill="black")

                        self.canvas.create_oval(ex - eye_size - 1.5, ey - eye_size * 0.7 - 1.5,
                                                ex + eye_size + 1.5, ey + eye_size * 0.7 + 1.5,
                                                fill="", outline="#ff1744", width=1)

                    # ЯЗЫК
                    tongue_start_x = joint_x + math.cos(head_angle) * head_size * 0.4
                    tongue_start_y = joint_y + math.sin(head_angle) * head_size * 0.4

                    tongue_flick = math.sin(now * 10) * 2
                    tongue_len = head_size * 0.7 + tongue_flick
                    tongue_angle = head_angle + jaw_open * 0.5

                    fork_len = tongue_len * 0.3

                    for fork_sign in [-1, 1]:
                        tip_x = tongue_start_x + math.cos(tongue_angle) * tongue_len + math.cos(
                            tongue_angle + 0.35 * fork_sign) * fork_len
                        tip_y = tongue_start_y + math.sin(tongue_angle) * tongue_len + math.sin(
                            tongue_angle + 0.35 * fork_sign) * fork_len

                        self.canvas.create_line(tongue_start_x, tongue_start_y,
                                                tip_x, tip_y,
                                                fill="#ff1744", width=2.5, capstyle="round")

                # Частицы у основания
                if random.random() < 0.3:
                    for _ in range(2):
                        angle = random.uniform(0, 2 * math.pi)
                        dist = random.uniform(p['radius'], p['radius'] + 25)
                        px = p['x'] + math.cos(angle) * dist
                        py = p['y'] + math.sin(angle) * dist

                        self.canvas.create_oval(px - 2, py - 2, px + 2, py + 2,
                                                fill="#ff5252", outline="")

            if p["char_type"] == "Isagi" and self.ball['dribbler'] == p and now < p['boost_until']:
                sim_x, sim_y = self.ball['x'], self.ball['y']
                sim_dx = math.cos(p['angle']) * 55
                sim_dy = math.sin(p['angle']) * 55
                pts = [(sim_x, sim_y)]
                for _ in range(20):
                    sim_x += sim_dx
                    sim_y += sim_dy
                    if sim_y < self.ball['radius'] or sim_y > self.sh - self.ball['radius']:
                        sim_dy *= -1
                        sim_y = max(self.ball['radius'], min(self.sh - self.ball['radius'], sim_y))
                    if sim_x < self.ball['radius'] or sim_x > self.sw - self.ball['radius']:
                        sim_dx *= -1
                        sim_x = max(self.ball['radius'], min(self.sw - self.ball['radius'], sim_x))
                    sim_dx *= 0.97
                    sim_dy *= 0.97
                    pts.append((sim_x, sim_y))
                self.canvas.create_line(pts, fill="#00ffff", dash=(4, 6), width=3)

            if p["char_type"] == "Rin" and self.ball[
                'dribbler'] == p and now < self.rin_ability_until and self.rin_ability_user == p:
                power = 55
                start_x = p['x'] + math.cos(p['angle']) * (p['radius'] + self.ball['radius'] + 2)
                start_y = p['y'] + math.sin(p['angle']) * (p['radius'] + self.ball['radius'] + 2)
                curve_pts = self.simulate_rin_curve(start_x, start_y, p['angle'], power)
                if len(curve_pts) > 1:
                    self.canvas.create_line(curve_pts, fill="#40E0D0", width=3, dash=(20, 10))

            if p["char_type"] == "Isagi" and now < p['boost_until']:
                for r_add, color in [(60, "#007a3d"), (40, "#00b99d"), (20, "#00e3dd")]:
                    ra = p['radius'] + r_add
                    self.canvas.create_oval(p['x'] - ra, p['y'] - ra, p['x'] + ra, p['y'] + ra, fill=color,
                                            outline="", stipple="gray25")

            dc = "#555555" if now < p['stunned_until'] else p['color']
            if p["char_type"] == "Hulk" and now < p['boost_until']:
                dc = "#2e7d32"
            if p["char_type"] == "Dio" and self.ts_factor > 0.5: dc = "gold"
            if p["char_type"] == "Pudge" and now < p.get("rot_until", 0): dc = "#3d6b3d"
            if p["char_type"] == "Naruto" and now < p.get("naruto_kyubi_until", 0): dc = "#ff4500"

            self.canvas.create_oval(p['x'] - p['radius'], p['y'] - p['radius'], p['x'] + p['radius'],
                                    p['y'] + p['radius'], fill=dc, outline="white", width=3)
            self.canvas.create_line(p['x'], p['y'], p['x'] + math.cos(p['angle']) * p['radius'],
                                    p['y'] + math.sin(p['angle']) * p['radius'], fill="white", width=4)

            if p["dialogue"]:
                txt_col_p = "gold" if p["char_type"] == "Dio" else ("orange" if p["char_type"] == "Naruto" else "white")
                self.canvas.create_text(p['x'], p['y'] - p['radius'] - 45,
                                        text=p["dialogue"], fill=txt_col_p,
                                        font=("Courier", 16, "bold"))

            if p["char_type"] == "Nagi":
                sx = random.randint(-3, 3) if now < p.get("shake_until", 0) else 0
                outl = "red" if now < p.get("shake_until", 0) else "white"
                bx, by = p['x'] - 30 + sx, p['y'] - p['radius'] - 30
                self.canvas.create_rectangle(bx, by, bx + 60, by + 7, fill="black", outline=outl)
                if p["nagi_charge"] > 0:
                    charge_color = "#FFFFFF" if p["nagi_charge"] >= 0.99 else "#cfd8dc"
                    self.canvas.create_rectangle(bx, by, bx + 60 * p["nagi_charge"], by + 7, fill=charge_color,
                                                 outline="")

            rem = max(0, p["dash_cd_until"] - now)
            if not self.no_cooldown:
                cd_duration = CHARACTER_TYPES[p["char_type"]]["cd"]
                ctype = p["char_type"]

                if ctype == "Hulk" and now < p.get('boost_until', 0):
                    ult_progress = (p['boost_until'] - now) / 4.0
                    extent = ult_progress * 359.9
                elif ctype == "Isagi" and now < p.get('boost_until', 0):
                    ult_progress = (p['boost_until'] - now) / 2.5
                    extent = ult_progress * 359.9
                elif ctype == "Rin" and self.rin_ability_user == p and now < self.rin_ability_until:
                    ult_progress = (self.rin_ability_until - now) / 4.0
                    extent = ult_progress * 359.9
                elif ctype == "Pudge" and now < p.get('rot_until', 0):
                    ult_progress = (p['rot_until'] - now) / 3.0
                    extent = ult_progress * 359.9
                elif ctype == "Naruto" and now < p.get('naruto_aura_until', 0):
                    ult_progress = (p['naruto_aura_until'] - now) / 4.0
                    extent = ult_progress * 359.9
                elif ctype == "Dio" and self.ts_owner == p and now < self.time_stop_until:
                    ult_progress = (self.time_stop_until - now) / 5.0
                    extent = ult_progress * 359.9
                else:
                    extent = (1 - rem / cd_duration) * 359.9

                arc_color = "#00ffff" if rem == 0 else "#ff3300"
                if ctype == "Hulk" and now < p.get('boost_until', 0):
                    arc_color = "#4caf50"
                elif ctype == "Isagi" and now < p.get('boost_until', 0):
                    arc_color = "#00e3dd"
                elif ctype == "Rin" and self.rin_ability_user == p and now < self.rin_ability_until:
                    arc_color = "#40E0D0"
                elif ctype == "Pudge" and now < p.get('rot_until', 0):
                    arc_color = "#2d8d2d"
                elif ctype == "Naruto" and now < p.get('naruto_aura_until', 0):
                    arc_color = "#ff8c00"
                elif ctype == "Dio" and self.ts_owner == p and now < self.time_stop_until:
                    arc_color = "#ffd700"

                self.canvas.create_arc(p['x'] - p['radius'] - 10, p['y'] - p['radius'] - 10, p['x'] + p['radius'] + 10,
                                       p['y'] + p['radius'] + 10, start=90,
                                       extent=extent,
                                       outline=arc_color, width=4, style="arc")

        for petal in self.kaiser_petals:
            if petal["life"] > 0:
                alpha = petal["life"] / petal["max_life"]
                size = petal["size"] * alpha

                petal_points = []
                num_points = 8
                for i in range(num_points):
                    angle = (i / num_points) * 2 * math.pi
                    r = size * (0.8 + 0.2 * math.cos(angle + math.pi / 2))
                    if i < num_points / 2:
                        r *= 1.3

                    px = petal["x"] + math.cos(angle + math.radians(petal["rotation"])) * r
                    py = petal["y"] + math.sin(angle + math.radians(petal["rotation"])) * r * 0.6
                    petal_points.extend([px, py])

                self.canvas.create_polygon(petal_points, fill=petal["color"], outline="#ffffff", width=0.5, smooth=True)

                center_angle = math.radians(petal["rotation"])
                vein_color = lighten_color(petal["color"], 0.4)
                for j in range(3):
                    vein_offset = (j - 1) * 0.3
                    vein_angle = center_angle + vein_offset
                    start_r = size * 0.2
                    end_r = size * 0.9
                    x1 = petal["x"] + math.cos(vein_angle) * start_r
                    y1 = petal["y"] + math.sin(vein_angle) * start_r * 0.6
                    x2 = petal["x"] + math.cos(vein_angle) * end_r
                    y2 = petal["y"] + math.sin(vein_angle) * end_r * 0.6
                    self.canvas.create_line(x1, y1, x2, y2, fill=vein_color, width=0.5)

        self.draw_football(self.ball['x'], self.ball['y'], self.ball['radius'], self.ball['rotation'])

        if self.goal_text_id:
            self.canvas.create_text(self.sw // 2, self.sh // 2, text=self.goal_text_id, fill="gold",
                                    font=("Arial", 160, "bold"))


# --- МЕНЮ ВЫБОРА ---
class Menu:
    def __init__(self):
        self.root = tk.Tk()
        self.root.title("Blue Lock Selection")
        self.root.configure(bg="#0a0a0a")
        self.root.geometry("1600x800")
        self.root.resizable(False, False)
        self.selections = []
        self.ai_mode = False
        self.switch_goals = 0

        self.label = tk.Label(self.root, text="ИГРОК 1: ВЫБЕРИ ГЕРОЯ", bg="#0a0a0a", fg="#00ffff", font=("Impact", 45))
        self.label.pack(pady=15)

        self.main_container = tk.Frame(self.root, bg="#0a0a0a")
        self.main_container.pack(expand=True, fill="both", padx=20)

        self.ai_frame = tk.Frame(self.main_container, bg="#0a0a0a")
        self.ai_frame.pack(pady=5)

        tk.Button(self.ai_frame, text="🤖 ИИ: Смена героев (1 ГОЛ)", bg="#7f0000", fg="white",
                  font=("Arial", 12, "bold"),
                  command=lambda: self.start_ai_mode(1)).pack(side="left", padx=10)
        tk.Button(self.ai_frame, text="🤖 ИИ: Смена героев (3 ГОЛА)", bg="#b71c1c", fg="white",
                  font=("Arial", 12, "bold"),
                  command=lambda: self.start_ai_mode(3)).pack(side="left", padx=10)
        tk.Button(self.ai_frame, text="🤖 ИИ: Смена героев (5 ГОЛОВ)", bg="#e53935", fg="white",
                  font=("Arial", 12, "bold"),
                  command=lambda: self.start_ai_mode(5)).pack(side="left", padx=10)

        row1 = ["Hulk", "Isagi", "Rin", "Pudge", "Dio"]
        row2 = ["Kaiser", "Nagi", "Aiku", "Naruto"]

        self.row1_frame = tk.Frame(self.main_container, bg="#0a0a0a")
        self.row1_frame.pack(fill="x", pady=15)
        self.row2_frame = tk.Frame(self.main_container, bg="#0a0a0a")
        self.row2_frame.pack(fill="x", pady=15)

        for i, c in enumerate(row1):
            self.row1_frame.grid_columnconfigure(i, weight=1)
            self.create_card(c, self.row1_frame, 0, i)
        for i, c in enumerate(row2):
            self.row2_frame.grid_columnconfigure(i, weight=1)
            self.create_card(c, self.row2_frame, 0, i)

    def start_ai_mode(self, switch_goals):
        chars = list(CHARACTER_TYPES.keys())
        c1, c2 = random.sample(chars, 2)
        self.selections = [c1, c2]
        self.ai_mode = True
        self.switch_goals = switch_goals
        self.root.destroy()

    def create_card(self, c, parent, r, col):
        card_size = 280
        info = CHARACTER_TYPES[c]
        base_colors = {"Rin": "#008080", "Hulk": "#1b5e20", "Isagi": "#0d47a1", "Pudge": "#8d6e63", "Aiku": "#7D26CD",
                       "Kaiser": "#0047AB", "Nagi": "#424242", "Dio": "#FFD700", "Naruto": "#FF6600"}
        base = base_colors[c]
        hover_color = lighten_color(base, 0.5)

        if c == "Dio":
            container = tk.Canvas(parent, bg="#111", highlightthickness=0, width=card_size, height=card_size)
            container.grid(row=r, column=col, padx=10, sticky="nsew")

            def draw_dio_border(event, cnv=container):
                w, h = event.width, event.height
                cnv.delete("border")
                cnv.create_polygon(0, 0, w, 0, 0, h, fill="#FFD700", tags="border")
                cnv.create_polygon(w, 0, w, h, 0, h, fill="#FFFF00", tags="border")

            container.bind("<Configure>", draw_dio_border)
            f = tk.Frame(container, bg="#111")
            f.place(x=4, y=4, relwidth=1, relheight=1, width=-8, height=-8)

        elif c in ["Aiku", "Kaiser", "Nagi", "Naruto"]:
            container = tk.Canvas(parent, bg="#111", highlightthickness=0, width=card_size, height=card_size)
            container.grid(row=r, column=col, padx=10, sticky="nsew")
            c2 = "#2e7d32" if c == "Aiku" else (
                "#800080" if c == "Kaiser" else ("#cfd8dc" if c == "Nagi" else "#000000"))

            def draw_border(event, cnv=container, c1=base, c2=c2):
                cnv.delete("border")
                cnv.create_rectangle(0, 0, event.width / 2, event.height, fill=c1, width=0, tags="border")
                cnv.create_rectangle(event.width / 2, 0, event.width, event.height, fill=c2, width=0, tags="border")

            container.bind("<Configure>", draw_border)
            f = tk.Frame(container, bg="#111")
            f.place(x=4, y=4, relwidth=1, relheight=1, width=-8, height=-8)
        else:
            f = tk.Frame(parent, bg="#111", highlightbackground=base, highlightthickness=4, width=card_size,
                         height=card_size)
            f.grid(row=r, column=col, padx=10, sticky="nsew")
            f.pack_propagate(False)

        tk.Label(f, text=info["name"], bg="#111", fg="white", font=("Arial", 20, "bold")).pack(pady=8)
        tk.Label(f, text=info.get("desc", ""), bg="#111", fg="#aaa", font=("Arial", 11), wraplength=200,
                 justify="center").pack(
            pady=2, fill="x")

        btn = tk.Button(f, text="ВЫБРАТЬ", bg=base, fg="white", font=("Arial", 12, "bold"),
                        activebackground=hover_color, activeforeground="white",
                        relief="raised", bd=2,
                        command=lambda x=c: self.set_choice(x))
        btn.pack(side="bottom", pady=15, padx=10, fill="x")

        btn.bind("<Enter>", lambda e, b=btn, orig=base, hov=hover_color: b.configure(bg=hov))
        btn.bind("<Leave>", lambda e, b=btn, orig=base: b.configure(bg=orig))

    def set_choice(self, char):
        self.selections.append(char)
        if len(self.selections) == 1:
            self.label.config(text="ИГРОК 2: ВЫБЕРИ ГЕРОЯ", fg="#ff3300")
        else:
            self.root.destroy()


if __name__ == "__main__":
    while True:
        m = Menu()
        m.root.mainloop()
        if len(m.selections) == 2:
            game = BlueLockPro2026(m.selections[0], m.selections[1], getattr(m, 'ai_mode', False),
                                   getattr(m, 'switch_goals', 0))
            game.root.mainloop()
        else:
            break